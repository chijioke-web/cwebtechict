 <?php

 session_start();
//creating class
 class WEB_CONTROL
 {
  
  public function connect(){
/*
   $host="localhost";
    $user="confide1_squix";
    $password="Ebenyi123@#";
    $dbb="confide1_squixx";
*/

    $host="localhost";
    $user="root";
    $password="";
    $dbb="squix";
 
    $connect= new mysqli($host,$user,$password,$dbb);

    if(!$connect){
        die("No server connection found");
    }
    return $connect;
  }



public function create_table($table_name,$field_data){

    $con=$this->connect();
$fields_data=implode(",", $field_data);
$creat_tb="create table if not exists ".$table_name."($fields_data)ENGINE=InnoDB;";
$sql=$con->query($creat_tb);
//echo "<i class='fa fa-exclamation-triangle'></i> success";
}


public function insert_value($tb,$fields,$values){
    $con=$this->connect();
$inser_field=implode(",", $fields);
$inser_values=implode('","',$values);


$insert='insert into '.$tb.'  ('.$inser_field. ') values("'.$inser_values.'")';
$sql=$con->query($insert);
}


public function register($tb,$pass,$pass2,$email,$ref_mail,$email_filed,$fields,$values,$name,$phone){

    $con=$this->connect();
    if($pass!=$pass2){
        echo "Password does not match";
    }
    else if(!is_numeric($phone)){
        echo "Please enter a valid phone number";
    }
    
    else if(!filter_var($email,FILTER_VALIDATE_EMAIL)){
        echo" Please enter a valid email address";
    }
    else if($ref_mail==$email){
        echo " Referral email cannot be same as personal email";
    }
    else if(!empty($email)){
        $sel="select * from $tb where $email_filed LIKE '$email%'";
        $sql=$con->query($sel);
        $row=$sql->fetch_assoc();
        
        if($sql->num_rows>=1){
            echo "Email address already in use";
        }
        else{

           $inser_field=implode(",", $fields);
$inser_values=implode('","',$values);


$insert='insert into '.$tb.'  ('.$inser_field. ') values("'.$inser_values.'")';

$result=$con->query($insert);
if($result){
    echo 1;
$selx="select * from $tb where $email_filed ='$email'";
        $sqlx=$con->query($selx);
        $rowx=$sqlx->fetch_assoc();
        $_SESSION['id']=$rowx['id'];
        $_SESSION['name']=$rowx['name'];
        $_SESSION['phone']=$rowx['phone'];
        $_SESSION['email']=$rowx['email'];
    $_SESSION['ref']=$rowx['ref_email'];
     $_SESSION['nation']=$rowx['nation'];
      $_SESSION['ref_id']=$rowx['ref_id'];
//message
require 'phpmailer/send.php';

}

else{
    echo "something wrong just happened. Try again";
}
        }
    }
}

public function check_user($tb,$ref,$ref_field){
$con=$this->connect();

$sel="select * from $tb where $ref='$ref_field'";
$sql=$con->query($sel);
if($sql->num_rows >=1 and !empty($ref_field)){
    echo"<font color='green'>Referral ID is correct and valid</font>";
}
elseif($sql->num_rows < 1 and !empty($ref_field)){
    echo"<font color='red'>Referral ID is invalid</font>";
}
else{
    echo '';
}


}


public function check_email($tb,$email,$uer_input){
$con=$this->connect();

$sel="select * from $tb where $email LIKE '$uer_input%'";
$sql=$con->query($sel);
if($sql->num_rows >=1 and !empty($uer_input)){
    echo"<font color='red'>Email is already in use</font>";
}
elseif($sql->num_rows < 1 and !empty($uer_input)){
    echo"<font color='green'>Email is available</font>";
}
else{
    echo '';
}


}

public function login($tb,$email,$email_field,$password,$pass,$block){

    $con=$this->connect();

    $sel="select * from $tb where $email_field='$email' and $password='$pass' and $block!=1 and verify=1";
    $sql=$con->query($sel);
    $num=$sql->num_rows;
    $row=$sql->fetch_assoc();
    $_SESSION['id']=$row['id'];
    $_SESSION['name']=$row['name'];
    $_SESSION['email']=$row['email'];
    $_SESSION['ref']=$row['ref_email'];
     $_SESSION['phone']=$row['phone'];
     $_SESSION['nation']=$row['nation'];
     $_SESSION['ref_id']=$row['ref_id'];
    if($num>=1){
        echo 1;
        $name=$_SESSION['name'];
        require 'phpmailer/send_login.php';
    }
    else{
        echo "Access Denied! Invalid Login credentials or email not verified";
    }
}


public function login_ad($tb,$email,$email_field,$password,$pass){

    $con=$this->connect();

    $sel="select * from $tb where $email_field='$email' and $password='$pass' ";
    $sql=$con->query($sel);
    $num=$sql->num_rows;
    $row=$sql->fetch_assoc();
    $_SESSION['idx']=$row['id'];
    $_SESSION['namex']=$row['name'];
    $_SESSION['email']=$row['email'];
     $_SESSION['nation']=$row['nation'];
    
    if($num>=1){
        echo 1;
    }
    else{
        echo "Access Denied! Invalid Login credentials";
    }
}
public function header_user_info($tb,$name,$nap){
    $con=$this->connect();
echo "<div class='txt-holder'>";
echo "<center>";
    echo "<div class='user-circle'><img src='$nap' id='user-pix'/></div>";
    echo"</center>";
    echo "<span class='user-main-text'><span class='user-text'>Welcome</span> $name</span> ";
    echo "</div>";
}

public function wallet_amount($tb,$id,$idd,$field){
    $con=$this->connect();

    $sel="select * from $tb where $id=$idd";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    
    echo "$".round($row[$field],3);
    echo"<br>";
    

   $_SESSION['wall']=$row[$field];
}

public function wallet_amount_btc($tb,$id,$idd,$field){
    $con=$this->connect();

    $sel="select * from $tb where $id=$idd";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    
    echo $row[$field];
    
    
   $_SESSION['wall']=$row[$field];
}

public function fund_wallet ($tb,$fields,$values){
    $con=$this->connect();

     $inser_field=implode(",", $fields);
$inser_values=implode('","',$values);




$insert='insert into '.$tb.'  ('.$inser_field. ') values("'.$inser_values.'")';

$result=$con->query($insert);
if($result){
    echo 1;

}
else{
    echo "something wrong just happened";
}
}
function transfer_fund_first($tb,$email,$email_field,$amount,$amount_field,$id,$idd,$sess_email){

    $con=$this->connect();
    $_SESSION['amount']=$amount;
    $_SESSION['ema']=$email;

   $sel="select * from $tb where $id=$idd";
   $sql=$con->query($sel);
   $row=$sql->fetch_assoc();
   if($amount>$row[$amount_field]){
    echo "You have insufficient fund.";
   }
   elseif($email==$sess_email){
    echo"You cannot transfer fund to yourself. You will be blocked next time you attempt this!";
   }
else{

    $selx="select * from $tb where $email_field='$email' and $email_field!='$sess_email'";
    $result=$con->query($selx);
    if($result->num_rows>=1){
        
    echo 1;
    
}
else{
    echo "Email address does not exists in our server";
}

}
}
public function transfer_complete($tb,$tpin,$pin_f,$pin,$id,$idd,$send_wallet,$email_filed,$email,$amount,$used,$not){
    $con=$this->connect();

    $sel="select * from $tpin where $pin_f='$pin' and $used=''";
    $sql=$con->query($sel);
    if($sql->num_rows>=1){
//update receiver wallet
$up="update $tb set
$send_wallet=$send_wallet+$amount where $email_filed='$email'";
$result=$con->query($up);
if($result){
    //update sender tb
    $upa="update $tb set
$send_wallet=$send_wallet-$amount where $id=$idd";
$sem=$con->query($upa);

    //update pin tb
  $upm="update $tpin set
  $used='$not' where $pin_f='$pin'";

  $sxl= $con->query($upm);
   //output
   echo 1;
}
    }
    else{
echo "Invalid OTP";
    }

}

public function trading($tb,$amount,$wallet,$id,$idd,$tb_trad,$fields,$values,$email,$ref,$paid,$refwallet,$per_ref){

    $con=$this->connect();
$sel="select * from $tb where $id=$idd and $paid=1";
$su=$con->query($sel);
if($su->num_rows<1){

    $sel="select * from $tb where $id=$idd";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    if($row[$wallet]<$amount){
        echo "You have insufficient fund";
    }
    else{
$inser_field=implode(",", $fields);
$inser_values=implode('","',$values);




$insert='insert into '.$tb_trad.'  ('.$inser_field. ') values("'.$inser_values.'")';

$result=$con->query($insert);

   if($result){
    $up="update $tb set 
$wallet=$wallet-$amount,$paid=1 where $id=$idd";
$sqlx=$con->query($up);
    
}
 if($sqlx) {
$upa="update $tb set 
    $refwallet=$refwallet+$per_ref where $email='$ref'";
    $semx=$con->query($upa);

 }
 if($semx){
    echo 1;
 } 
else{
    echo "Investment failed";
   }   
}
}
else{

$sel="select * from $tb where $id=$idd";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    if($row[$wallet]<$amount){
        echo "You have insufficient fund";
    }
    else{
$inser_field=implode(",", $fields);
$inser_values=implode('","',$values);




$insert='insert into '.$tb_trad.'  ('.$inser_field. ') values("'.$inser_values.'")';

$result=$con->query($insert);

   if($result){
    $up="update $tb set 
$wallet=$wallet-$amount where $id=$idd";
$sqlx=$con->query($up);
    
}
 if($sqlx) {

    echo 1;
 } 
else{
    echo "Investment failed";
   }   

}
 }   
}

public function mining($tb,$amount,$wallet,$id,$idd,$tb_trad,$fields,$values){

    $con=$this->connect();

    $sel="select * from $tb where $id=$idd";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    if($row[$wallet]<$amount){
        echo "You have insufficient fund";
    }
    else{
$inser_field=implode(",", $fields);
$inser_values=implode('","',$values);




$insert='insert into '.$tb_trad.'  ('.$inser_field. ') values("'.$inser_values.'")';

$result=$con->query($insert);

   if($result){
    $up="update $tb set 
$wallet=$wallet-$amount where $id=$idd";
$sqlx=$con->query($up);
    echo 1;
}
   else{
    echo "something wrong just happened. Try again later";
   } 
   }   
    
}

public function total_trad_min($tb,$id,$idd,$total,$amount,$idr){
    $con=$this->connect();

    $sel="select $idr,$amount,sum($amount) as $total from $tb where $id=$idd";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    echo "<s>N</s>".number_format($row[$total]);
}

public function fund_wallet_buttons($tb,$id,$idd,$field){
    $con=$this->connect();

    $sel="select * from $tb where $id=$idd";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    
    
    echo"<br>";
    if($row[$field]>=1){

echo '<a href="#u/o/?/page=widthdraw_wallet_fund"><button type="button" class="withdraw">Withdraw Fund</button></a>';
}
if($row[$field]>=100){
echo '<a href="#u/o/?/page=trading"><button type="button" class="withdraw">Make Investment</button></a>';
 } 

echo '<a href="#u/o/?/page=fund_wallet" class="index"><button type="button" class="withdraw">Fund Wallet</button></a>';
   
}
public function width_bonus_buttons($tb,$id,$idd,$field){
    $con=$this->connect();

    $sel="select * from $tb where $id=$idd";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    
    
    echo"<br>";
    if($row[$field]>=100){

echo '<a href="#u/o/?/page=widthdraw_bonus_fund"><button type="button" class="withdraw">Withdraw Fund</button></a>';
 } 


   
}
public function number_ref($tb,$email,$ref_mail){
    $con=$this->connect();
    $sel="select * from $tb where $ref_mail='$email'";
    $sql=$con->query($sel);
    $num=$sql->num_rows;
    echo number_format($num);


}

function withdrawal_from_wallet($tb,$id,$idd,$wallet,$amount,$any_f,$any_n,$any_b){

    $con=$this->connect();
    if(!is_numeric($amount)){
        echo "please enter a valid amount to withdraw";
    }
    else{
    $sel="select * from $tb where $id=$idd";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    if($row[$wallet] < $amount){
        echo "You have insufficient fund";
    }
    else{
       
echo 1;

$_SESSION['with_amount']=$amount;
$_SESSION['accno']=$any_f;
$_SESSION['accna']=$any_n;
$_SESSION['bank']=$any_b;
}
 }   
}
public function final_withdraw($tb,$tpin,$tw,$pin,$pina,$used,$not,$id,$idd,$fields,$values,$wallet,$amount,$with,$use_up){
    $con=$this->connect();

    $sel="select * from $tpin where $pin='$pina' and $used='$not'";
    $sql=$con->query($sel);
    $num=$sql->num_rows;
    if($num>=1){
$inser_field=implode(",", $fields);
$inser_values=implode('","',$values);
$insert='insert into '.$tw.'  ('.$inser_field. ') values("'.$inser_values.'")';

$result=$con->query($insert);

if($result){

    $up="update $tb set 
$wallet=$wallet-$amount where $id=$idd";
$rem=$con->query($up);

if($rem){
     $upa="update $tb set 
$with=$with+$amount where $id=$idd";
$rema=$con->query($upa);  

$upm="update $tpin set 

$used='$use_up' where $pin='$pina'";

$sqlc=$con->query($upm);
echo 1;

}

}
else{
    echo "something wrong just happened. Try again later";
}

    }
    else{
        echo "Invalid OTP";
    }
}

function withdrawal_from_bonus($tb,$id,$idd,$wallet,$amount,$any_f,$any_n,$any_b){

    $con=$this->connect();
    if(!is_numeric($amount)){
        echo "please enter a valid amount to withdraw";
    }
    else{
    $sel="select * from $tb where $id=$idd";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    if($row[$wallet] < $amount){
        echo "You have insufficient fund";
    }
    
    else{
       
echo 1;

$_SESSION['with_amount']=$amount;
$_SESSION['accno']=$any_f;
$_SESSION['accna']=$any_n;
$_SESSION['bank']=$any_b;
}
}  
}
public function final_withdraw_bonus($tb,$tpin,$tw,$pin,$pina,$used,$not,$id,$idd,$fields,$values,$wallet,$amount,$with,$use_up){
    $con=$this->connect();

    $sel="select * from $tpin where $pin='$pina' and $used='$not'";
    $sql=$con->query($sel);
    $num=$sql->num_rows;
    if($num>=1){
$inser_field=implode(",", $fields);
$inser_values=implode('","',$values);
$insert='insert into '.$tw.'  ('.$inser_field. ') values("'.$inser_values.'")';

$result=$con->query($insert);

if($result){

    $up="update $tb set 
$wallet=$wallet-$amount where $id=$idd";
$rem=$con->query($up);

if($rem){
     $upa="update $tb set 
$with=$with+$amount where $id=$idd";
$rema=$con->query($upa);  

$upm="update $tpin set 

$used='$use_up' where $pin='$pina'";

$sqlc=$con->query($upm);
echo 1;
}

}
else{
    echo "something wrong just happened. Try again later";
}

    }
    else{
        echo "Invalid OTP";
    }
}

public function show_current_trad($tb,$id,$idd,$status,$active,$traid,$amount,$percent,$acrued,$profit,$days,$start,$end){
    $con=$this->connect();

    $sel="select * from $tb where $id=$idd and $status='$active'";
    $sql=$con->query($sel);
    echo "<div class='table_control'>";
    echo "<h2 align='center'>Active Investment</h2>";
   // echo '<center><img src="pix/gear.gif" width="100"></center>';
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
<th>Investment ID</th>
<th>Amount Invested</th>
<th>Daily % ROI</th>
<th>Capital + Profit</th>
<th>Day(s) Traded</th>
<th>Package</th>

<th>Start Date</th>
<th>End Date</th>
<th>Status</th><th></th></tr>";
    $sn=1;
while($row=$sql->fetch_assoc()){?>

     

    <tr align="center" style="font-size:12px;font-weight:bold;font-family: microsoft new tai lue;"><td><?php echo$sn++;?></td><td><?php echo $row[$traid];?></td><td>$<?php echo round($row[$amount],3);?></td><td>$<?php echo round($row[$percent],3);?></td><td><font color="blue" size="+2">$<?php echo round($row[$acrued],3);?></font><br><?php /*if($row[$acrued]>=1){?><form id="formxp<?php echo $row['id'];?>" method="post"><button type="submit" class="btn<?php echo $row['id'];?>"> Transfer profit to wallet</button><input type="hidden" name="profit" value="<?php echo $row[$acrued];?>"><input type="hidden" name="id" value="<?php echo $row['id'];?>"> </form><?php } ?> <div class="loader<?php echo $row['id'];?>" style=" display: none;"></div><div class="msg<?php echo $row['id'];?>"></div>*/?></td><td><?php echo ($row['days_with']);?></td><td><?php echo ($row['plan']);?></td><td><?php echo $row[$start];?></td><td><?php echo $row[$end];?></td><td><font color='green'><?php echo $row[$status];?></font></td> <td><img src="pix/gear.gif" width="40"></td></tr>


    <script type="text/javascript">
        
//update wallet
$("#formxp<?php echo $row['id'];?>").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "transfer_to_wallet.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".btn<?php echo $row['id'];?>").html("please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.9","cursor":"not-allowed"});
    $(".btn<?php echo $row['id'];?>").attr("disabled",true);
    $(".loader<?php echo $row['id'];?>").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg<?php echo $row['id'];?>").fadeIn(2000);
      $(".msg<?php echo $row['id'];?>").html('successful <img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader<?php echo $row['id'];?>").hide(10);

             setTimeout('window.location.href="dashboard";',1000); 
            }
            else{ 
              
          $(".msg<?php echo $row['id'];?>").fadeIn(2000);
          $(".msg<?php echo $row['id'];?>").css("background-color","red");
      $(".msg<?php echo $row['id'];?>").html(data);
  $(".btn<?php echo $row['id'];?>").html('Transfer profit to wallet').css({"opacity":"1","cursor":"pointer"});
  $(".loader<?php echo $row['id'];?>").hide(10);
  $(".btn<?php echo $row['id'];?>").attr("disabled",false);
  setTimeout(function(){$(".msg<?php echo $row['id'];?>").fadeOut(2000)},3000);
}
        }
           
     });
  });


    </script>
    <style>
.msg<?php echo $row['id'];?>{
    width: 100%;
    border-radius: 20px;
    padding: 10px;
    color: white;
    font-weight: bold;
    font-family: arial;
    display: none;
    margin: auto;
    text-align: center;
}
    </style>


    <?php 
}
?>
</table>
</div>
<?php 
}

public function show_current_min($tb,$id,$idd,$status,$active,$traid,$amount,$percent,$acrued,$profit,$days,$start,$end){
    $con=$this->connect();

    $sel="select * from $tb where $id=$idd and $status='$active'";
    $sql=$con->query($sel);
    echo "<div class='table_control'>";
    echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
<th>Mining ID</th>
<th>Amount Invested</th>
<th>2% Daily profit</th>
<th>Accrued Profit</th>
<th>Profit + Capital</th>
<th>Day(s) Traded</th>
<th>Start Date</th>
<th>End Date</th>
<th>Status</th><th></th></tr>


    ";
    $sn=1;
while($row=$sql->fetch_assoc()){

    echo "<tr align='center' style='font-size:12px;font-weight:bold;font-family: microsoft new tai lue;'><td>".$sn++."</td><td>".$row[$traid]."</td><td>".number_format($row[$amount])."</td><td>".number_format($row[$percent])."</td><td>".number_format($row[$acrued])."</td><td>".number_format($row[$profit])."</td><td>".$row[$days]."</td><td>".$row[$start]."</td><td>".$row[$end]."</td><td><font color='green'>".$row[$status]."</font></td> <td><img src='pix/aro.gif' width='30' ></td></tr>";
}
echo "</table>";
echo "</div>";
}

public function calculate_trade_profit($tb,$day,$no_days,$profit,$per){

    $con=$this->connect();

    $up="update $tb set 
    days_with=days_with+1,$profit=$profit+$per where $day!=$no_days";

    $sql=$con->query($up);
}

public function enter_profit($tb,$td,$id,$idt,$idd,$idr,$wallet,$amount,$total,$status,$complete,$active,$days,$day_field){
    $con=$this->connect();

    $sel="select $idr,$amount,sum($amount) as $total from $td where $idt=$idd and $status='$active' and $day_field=$days";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    $tot=$row[$total];
    if($sql){
        $up="update $tb set 
$wallet=$wallet+$tot where $id=$idd";
$sem=$con->query($up);
if($sem){
    $upa="update $td set 
    $status='$complete' where $idt= $idd and $day_field=$days and $status='$active'";
    $sep=$con->query($upa);

    }
}
}

public function enter_profit_min($tb,$td,$id,$idt,$idd,$idr,$wallet,$amount,$total,$status,$complete,$active,$days,$day_field){
    $con=$this->connect();

    $sel="select $idr,$amount,sum($amount) as $total from $td where $idt=$idd and $status='$active' and $day_field=$days";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    $tot=$row[$total];
    if($sql){
        $up="update $tb set 
$wallet=$wallet+$tot where $id=$idd";
$sem=$con->query($up);
if($sem){
    $upa="update $td set 
    $status='$complete' where $idt= $idd and $day_field=$days and $status='$active'";
    $sep=$con->query($upa);

    }
}
}
public function update_bank_details($tb,$id,$idd,$ac_f,$acno,$ac_n,$acna,$b_n,$bn){
    $con=$this->connect();

    $up="update $tb set 
$ac_f='$acno',$ac_n='$acna',$b_n='$bn' where $id=$idd";

$sql=$con->query($up);
if($sql){
    echo 1;
}
else{
    echo "An error just occurred. Try again later";
}
}
function change_password($pass){

    $con=$this->connect();
    $_SESSION['passx']=$pass;
    echo 1;

}

public function change_pass_function($tb,$id,$idd,$pass_field,$pass,$pin_f,$pin,$tp,$used,$empty,$us){
    $con=$this->connect();

$sel="select * from $tp where $pin_f='$pin' and $used='$empty'";
$sql=$con->query($sel);
if($sql->num_rows>=1){

    $up="update $tb set 
    $pass_field='$pass' where $id=$idd";
    $sem=$con->query($up);

    if($sem){
        $upa="update $tp set 
        $used='$us' where $pin_f='$pin'";
        $sx=$con->query($upa);
        echo 1;
    }
}
else{
    echo "Invalid OTP";
}
}

public function send_txt($tb,$fields,$values){
    $con=$this->connect();
    $inser_field=implode(",", $fields);
$inser_values=implode('","',$values);




$insert='insert into '.$tb.'  ('.$inser_field. ') values("'.$inser_values.'")';

$result=$con->query($insert);
if($result){
    echo 1;

}
else{
    echo "error in sending message";
}
}


public function show_reff($tb,$email,$em,$phone,$name,$mail){
    $con=$this->connect();

    $sel="select * from $tb where $email='$em'";
    $sql=$con->query($sel);
    //echo "<br><br><br>";
    if($sql->num_rows<1){
        echo "You have not referred anyone";
    }else{
    echo "<div class='table_control'>";
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
<th>Name</th>
<th>Phone</th>
<th>Email</th>
</tr>


    ";
    $sn=1;
while($row=$sql->fetch_assoc()){

     echo "<tr align='center' style='font-size:12px;font-weight:bold;font-family: microsoft new tai lue;'><td>".$sn++."</td><td>".$row[$name]."</td><td>".$row[$phone]."</td><td>".$row[$mail]."</td></tr>";
}
echo "</table>";
echo "</div>";
}
}


public function trading_history($tb,$id,$idd,$status,$active,$traid,$amount,$percent,$acrued,$profit,$days,$start,$end){
    $con=$this->connect();

    $sel="select * from $tb where $id=$idd ";
    $sql=$con->query($sel);
    echo "<div class='table_control'>";
    //echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
<th>Investment ID</th>
<th>Amount Invested</th>
<th>10% Daily profit</th>
<th>Accrued Profit</th>

<th>Day(s) Traded</th>
<th>Start Date</th>
<th>End Date</th>
<th>Status</th></tr>


    ";
    $sn=1;
while($row=$sql->fetch_assoc()){

    echo "<tr align='center' style='font-size:12px;font-weight:bold;font-family: microsoft new tai lue;'><td>".$sn++."</td><td>".$row[$traid]."</td><td>$".round($row[$amount],3)."</td><td>$".round($row[$percent],3)."</td><td>$".round($row[$acrued],3)."</td><td>".$row[$days]."</td><td>".$row[$start]."</td><td>".$row[$end]."</td><td><font color='green'>".$row[$status]."</font></td></tr>";
}
echo "</table>";
echo "</div>";
}

public function mining_history($tb,$id,$idd,$status,$active,$traid,$amount,$percent,$acrued,$profit,$days,$start,$end){
    $con=$this->connect();

    $sel="select * from $tb where $id=$idd ";
    $sql=$con->query($sel);
    echo "<div class='table_control'>";
    //echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
<th>Mining ID</th>
<th>Amount Invested</th>
<th>2% Daily profit</th>
<th>Accrued Profit</th>
<th>Profit + Capital</th>
<th>Day(s) Traded</th>
<th>Start Date</th>
<th>End Date</th>
<th>Status</th></tr>


    ";
    $sn=1;
while($row=$sql->fetch_assoc()){

    echo "<tr align='center' style='font-size:12px;font-weight:bold;font-family: microsoft new tai lue;'><td>".$sn++."</td><td>".$row[$traid]."</td><td>".number_format($row[$amount])."</td><td>".number_format($row[$percent])."</td><td>".number_format($row[$acrued])."</td><td>".number_format($row[$profit])."</td><td>".$row[$days]."</td><td>".$row[$start]."</td><td>".$row[$end]."</td><td><font color='green'>".$row[$status]."</font></td></tr>";
}
echo "</table>";
echo "</div>";
}

public function deposit_history($tb,$id,$idd,$date,$amount,$status){
    $con=$this->connect();

    $sel="select * from $tb where $id=$idd ";
    $sql=$con->query($sel);
    echo "<div class='table_control'>";
    //echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
<th>Amount </th>
<th>Date </th>
<th>Status</th></tr>



    ";
    $sn=1;
while($row=$sql->fetch_assoc()){?>

    <tr align='center' style='font-size:12px;font-weight:bold;font-family: microsoft new tai lue;'><td><?php echo $sn++;?></td><td>$<?php echo round($row[$amount],3);?></td><td><?php echo $row[$date];?></td><td><?php if($row[$status]=='pending'){?><font color='red'><?php echo $row[$status];?></font><?php }else{?><font color='green'><?php echo $row[$status];?></font><?php } ?></td></tr>
    <?php
}
echo "</table>";
echo "</div>";
}


public function send_email_public($na,$msg,$phone,$city,$email){
    $con=$this->connect();


    $message =$msg;
$ga="Dear BitralaxFx admin";

//mail body - image position, background, font color, font size...
$body ='<html>
<head>
<style>
body
{
background:yellow;
font-family: "lucida grande", tahoma, verdana;
font-size:16px;
font-weight: bold;
color: #fff;
}
.content{
overflow:hidden;
background-color: white;

padding:10px;
width:100%;
}
</style>
</head>
<body>
<div class="content">
<hr><br /><br>
<h1>'.$ga.'</h1>
<h5>My phone no:'.$phone.'</h5>
<h5>My city:'.$city.'</h5>
'.$message.'

</div>
</body>';
//to send HTML mail, the Content-type header must be set:
$headers='MIME-Version: 1.0' . "\r\n";
$headers .= 'Content-type: text/html;charset=iso-8859-1' . "\r\n";
$headers .= 'From: BitralaxFx  <info@BitralaxFx.com>' . "\r\n";
$headers .= 'Reply-To:'.$email . "\r\n";
$to = 'classic44life@gmail.com';
$too = 'Cointrxcom@gmail.com';
$subject = " Message from ".$na;
//mail function
@$mail = mail($to, $subject, $body, $headers);
@$mail2 = mail($too, $subject, $body, $headers);
if(@$mail){
    echo 1;
}
else{
    echo "Mail sending error. Try again later";
}
}

public function news_letter($email){

    echo 1;
}

public function forgot_password($tb,$email,$ema){

    $con=$this->connect();

    $select="select * from $tb where $email='$ema'";
    $sql=$con->query($select);
    $row=$sql->fetch_assoc();
    if($sql->num_rows >=1){
     $name=$row['name'];
        require 'phpmailer/send_recover_pass.php';
echo 1;
    }
    else{
        echo "User with ".$ema. " does not exists";
    }
}

public function reset_password_final($tb,$email,$pass_f,$em,$pass,$pa,$password){
    $con=$this->connect();

    if($pass!=$pa){
        echo "Password does not match";
    }
    else{
        $up="update $tb set 
$pass_f='$password' where $email='$em'";

$sql=$con->query($up);

if($sql){
    echo 1;
    }
    else{
        echo "Password reset error just occurred. Try again";
    }
}
}


public function total_trad_min_public($tb,$total,$amount,$idr,$add){
    $con=$this->connect();

    $sel="select $idr,$amount,sum($amount) as $total from $tb";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    echo "$".number_format($row[$total]+$add);
}

public function total_trad_min_public_activ($tb,$total,$amount,$idr,$add,$status,$active){
    $con=$this->connect();

    $sel="select $idr,$amount,sum($amount) as $total from $tb where $status='$active'";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    echo "$".number_format($row[$total]+$add);
}

public function total_reg($tb,$add){
    $con=$this->connect();

    $sel="select * from $tb";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    echo number_format($sql->num_rows+$add);
}


public function view_member($tb,$name,$phone,$email,$ref,$wallet,$refwallet,$date,$id){
    $con=$this->connect();

    $sel="select * from $tb";
    $sql=$con->query($sel);
    echo "<div class='table_control' id='memba'>";
    //echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
<th>Name</th>
<th>phone</th>
<th>Email</th>
<th>Wallet</th>
<th>Ref Bonus</th>
<th>Date </th>
<th></th>
<th></th></tr>


    ";
    $sn=1;
while($row=$sql->fetch_assoc()){

    echo "<tr align='center' style='font-size:12px;font-weight:bold;font-family: microsoft new tai lue;'><td>".$sn++."</td><td>".$row[$name]."</td><td>".$row[$phone]."</td><td>".$row[$email]."</td><td>$".number_format($row[$wallet])."</td><td>$".number_format($row[$refwallet])."</td><td>".$row[$date]."</td><td><a href='block_user_script?user=$row[$id]' onclick='return(show_diag())'><button  type='button'>"?><?php if($row['country']!=1){?>Block User<?php }else{ ?> Unblock User<?php } echo "</button></a></td><td><a href='access_script?user=$row[$id]' target='_blank'><button type='button'>Access Dashboard</button></a></td></tr>";
}
echo "</table>";
echo "</div>";
}


public function block_user($tb,$id,$idd,$block,$block_value,$blo){
    $con=$this->connect();
$sel="select * from $tb where $id=$idd and $block=1";
$sem=$con->query($sel);
if($sem->num_rows<1){
    $up="update $tb set 
    $block=$block_value where $id=$idd";
    $sql=$con->query($up);
    if($sql){
        header("location:admin");
    }

}
else{
    $upx="update $tb set 
    $block='$blo' where $id=$idd";
    $sqlx=$con->query($upx);
    if($sqlx){
        header("location:admin");
    }
}
}
 public function access_dashboard($tb,$id,$idd,$name,$email){
    $con=$this->connect();

    $sel="select * from $tb where $id=$idd";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    $_SESSION['id']=$row['id'];
    $_SESSION['name']=$row['name'];
    $_SESSION['email']=$row['email'];
    $_SESSION['phone']=$row['phone'];
    $_SESSION['ref']=$row['ref_email'];
     $_SESSION['nation']=$row['nation'];
     $_SESSION['ref_id']=$row['ref_id'];
    header("location:dashboard");
 }


 public function fund_user_wallet($tb,$name,$phone,$ref,$amount,$id,$idd,$status,$active,$date){
    $con=$this->connect();

    $sel="select * from $tb where $status='$active' ";
    $sql=$con->query($sel);
    echo "<div class='table_control'>";
    //echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<form id='del_all' method='post'>";
    echo "<button type='submit' class='btn' style='background:black; color:white; border-radius:20px; border:0px; padding:15px;width:150px' onclick='return(conffax())'>Delete All</button>";
    echo "</form>";
    echo "<div class='msg'></div>";
    echo "<table align='center' cellpadding='10' cellspacing='0' width='100%' id='tb_trad' border='0'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th></th>
<th>Name</th>

<th>Amount Paid</th>
<th>Coin</th>
<th>From</th>
<th>To</th>

<th>Date </th>
<th>Status </th>
</tr>


    ";
    $sn=1;
while($row=$sql->fetch_assoc()){?>

    <script type="text/javascript">
        
//update wallet
$("#frm<?php echo $row[$id];?>").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "update_user_wallet_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".btn<?php echo $row[$id];?>").html("please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".btn<?php echo $row[$id];?>").attr("disabled",true);
    $(".loader<?php echo $row[$id];?>").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg<?php echo $row[$id];?>").fadeIn(1000);
      $(".msg<?php echo $row[$id];?>").html('wallet updated...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader<?php echo $row[$id];?>").hide(10);

           setTimeout(function(){$(".main").load('fund_user_wallet.php')},1000);
         
           
            }
            else{ 
              
          $(".msg<?php echo $row[$id];?>").fadeIn(2000);
          $(".msg<?php echo $row[$id];?>").css("background-color","red");
      $(".msg<?php echo $row[$id];?>").html(data);
  $(".btn<?php echo $row[$id];?>").html('Update Wallet').css({"opacity":"1","cursor":"pointer"});
  $(".loader<?php echo $row[$id];?>").hide(10);
  $(".btn<?php echo $row[$id];?>").attr("disabled",false);
  setTimeout(function(){$(".msg<?php echo $row[$id];?>").fadeOut(2000)},3000);
}
        }
           
     });
  });
  
//delete

//update wallet
$("#del<?php echo $row[$id];?>").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "delete_deposit_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".btndel<?php echo $row[$id];?>").html("please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".btndel<?php echo $row[$id];?>").attr("disabled",true);
    $(".loader<?php echo $row[$id];?>").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg<?php echo $row[$id];?>").fadeIn(1000);
      $(".msg<?php echo $row[$id];?>").html('Deleted...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader<?php echo $row[$id];?>").hide(10);

             setTimeout(function(){$(".main").load('fund_user_wallet.php')},1000);
            }
            else{ 
              
          $(".msg<?php echo $row[$id];?>").fadeIn(2000);
          $(".msg<?php echo $row[$id];?>").css("background-color","red");
      $(".msg<?php echo $row[$id];?>").html(data);
  $(".btndel<?php echo $row[$id];?>").html('Delete').css({"opacity":"1","cursor":"pointer"});
  $(".loader<?php echo $row[$id];?>").hide(10);
  $(".btndel<?php echo $row[$id];?>").attr("disabled",false);
  setTimeout(function(){$(".msg<?php echo $row[$id];?>").fadeOut(2000)},3000);
}
        }
           
     });
  });

    </script>
    <style>
.msg<?php echo $row[$id];?>{
    width: 100%;
    border-radius: 20px;
    padding: 10px;
    color: white;
    font-weight: bold;
    font-family: arial;
    display: none;
    margin: auto;
    text-align: center;
}
    </style>
    <tr align="center">
        <td><form id='del<?php echo $row[$id];?>' method='post'>
<button type="submit" class="btndel<?php echo $row[$id];?>" onclick="return(conffax())"> Delete</button>
<input type="hidden" name="idel" value="<?php echo $row['id'];?>">
</form></td>
        <td><?php echo $row[$name];?></td>
    
       <td><form id='frm<?php echo $row[$id];?>' method='post'>

<input type="number" name="amount" value="<?php echo $row[$amount];?>" style="width:100px">

<button type="submit" class="btn<?php echo $row[$id];?>"> Update Wallet</button>
<input type="hidden" name="id" value="<?php echo $row[$idd];?>">
<input type="hidden" name="ref" value="<?php echo $row['ref'];?>">
<input type="hidden" name="idff" value="<?php echo $row['id'];?>">
<input type="hidden" name="phone" value="<?php echo $row['phone'];?>">
<input type="hidden" name="name" value="<?php echo $row['name'];?>">
<input type="hidden" name="email" value="<?php echo $row['email'];?>">
<input type="hidden" name="coin" value="<?php echo $row['coin'];?>">
</form>
<div class="loader<?php echo $row[$id];?>" style=" display: none;"><img src="pix/loading51.gif" class="load_in" style="width:30px;"></div><div class="msg<?php echo $row[$id];?>"></div>

       </td><td><?php echo $row['coin'];?></td> <td><?php echo $row['pay_from'];?></td> <td><?php echo $row['wallet_add'];?></td><td><?php echo $row[$date];?></td> <td><font color="red"><?php echo $row[$status];?></font></td></tr><?php } 
      echo "</table>";
      echo "</div>";
}

public function fund_wallet_admin_final($tb,$id,$idd,$email,$ref,$tf,$idf,$idff,$wallet,$refwallet,$amount,$per,$status,$active,$paid){

$con=$this->connect();
$up="update $tb set 
$wallet=$wallet+$amount where $id=$idd";
$sql=$con->query($up);
if($sql){
    
     $upam="update $tf set 
    $status='$active' where $idf=$idff";
    $sema=$con->query($upam);

if($sema){
    echo 1;

}
else{
    echo "Updating user wallet failed";

}
}
}


public function pay_user($tb,$name,$amount,$id,$status,$active,$date,$accno,$accna,$bank){
    $con=$this->connect();

    $sel="select * from $tb where $status='$active'";
    $sql=$con->query($sel);
    echo "<div class='table_control'>";
    //echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='0' width='100%' id='tb_trad' border='0'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
<th>Name</th>
<th>Amount</th>
<th>Coin</th>
<th>Wallet Address</th>
<th>Network</th>
<th>Date </th>
<th>Status </th>
<th></th>
<th></th>
<th></th>
</tr>


    ";
    $sn=1;
while($row=$sql->fetch_assoc()){?>

    <script type="text/javascript">
        
//update wallet
$("#frm<?php echo $row[$id];?>").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "comfirm_with_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".btn<?php echo $row[$id];?>").html("please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".btn<?php echo $row[$id];?>").attr("disabled",true);
    $(".loader<?php echo $row[$id];?>").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg<?php echo $row[$id];?>").fadeIn(2000);
      $(".msg<?php echo $row[$id];?>").html('payment confirmed...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader<?php echo $row[$id];?>").hide(10);

             setTimeout(function(){$(".main").load('pay_withdrawal.php')},2000);
            }
            else{ 
              
          $(".msg<?php echo $row[$id];?>").fadeIn(2000);
          $(".msg<?php echo $row[$id];?>").css("background-color","red");
      $(".msg<?php echo $row[$id];?>").html(data);
  $(".btn<?php echo $row[$id];?>").html('Confirm').css({"opacity":"1","cursor":"pointer"});
  $(".loader<?php echo $row[$id];?>").hide(10);
  $(".btn<?php echo $row[$id];?>").attr("disabled",false);
  setTimeout(function(){$(".msg<?php echo $row[$id];?>").fadeOut(2000)},3000);
}
        }
           
     });
  });
  //decline
//update wallet
$("#decl<?php echo $row[$id];?>").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "decline_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".btnd<?php echo $row[$id];?>").html("please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.7","cursor":"not-allowed"});
    $(".btnd<?php echo $row[$id];?>").attr("disabled",true);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg<?php echo $row[$id];?>").fadeIn(2000);
      $(".msg<?php echo $row[$id];?>").html('Withdrawal declined...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      
             setTimeout(function(){$(".main").load('pay_withdrawal.php')},2000);
            }
            else{ 
              
          $(".msg<?php echo $row[$id];?>").fadeIn(2000);
          $(".msg<?php echo $row[$id];?>").css("background-color","red");
      $(".msg<?php echo $row[$id];?>").html(data);
  $(".btnd<?php echo $row[$id];?>").html('Decline').css({"opacity":"1","cursor":"pointer"});

  $(".btnd<?php echo $row[$id];?>").attr("disabled",false);
  setTimeout(function(){$(".msg<?php echo $row[$id];?>").fadeOut(2000)},3000);
}
        }
           
     });
  });
//delete

//update wallet
$("#dele<?php echo $row[$id];?>").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "deletewithdraw_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".btndel<?php echo $row[$id];?>").html("please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.7","cursor":"not-allowed"});
    $(".btndel<?php echo $row[$id];?>").attr("disabled",true);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg<?php echo $row[$id];?>").fadeIn(2000);
      $(".msg<?php echo $row[$id];?>").html('Deleted...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      

             setTimeout(function(){$(".main").load('pay_withdrawal.php')},2000);
            }
            else{ 
              
          $(".msg<?php echo $row[$id];?>").fadeIn(2000);
          $(".msg<?php echo $row[$id];?>").css("background-color","red");
      $(".msg<?php echo $row[$id];?>").html(data);
  $(".btndel<?php echo $row[$id];?>").html('Confirm').css({"opacity":"1","cursor":"pointer"});
  $(".btndel<?php echo $row[$id];?>").attr("disabled",false);
  setTimeout(function(){$(".msg<?php echo $row[$id];?>").fadeOut(2000)},3000);
}
        }
           
     });
  });


$("#coy<?php echo $row[$id];?>").click(function(){
var copy=document.getElementById('cop<?php echo $row[$id];?>');
copy.select();
document.execCommand('copy');
$(".msg<?php echo $row[$id];?>").fadeIn(1000);
   $(".msg<?php echo $row[$id];?>").html('Copied');
   
$(".msg<?php echo $row[$id];?>").css({"background-color":"rgba(0,0,0,0.9)","color":"white","border-radius":"20px"});
   setTimeout(function(){$(".msg<?php echo $row[$id];?>").fadeOut(2000)},3000);
});
    </script>
    <style>
.msg<?php echo $row[$id];?>{
    width: 100%;
    border-radius: 20px;
    padding: 10px;
    color: white;
    font-weight: bold;
    font-family: arial;
    display: none;
    margin: auto;
    text-align: center;
}
    </style>
    <tr align="center">
        <td><?php echo $sn++;?></td>
        <td><?php echo $row[$name];?></td>
       <td>$<?php echo $row[$amount];?></td>
       
       <td><?php echo $row[$accno];?></td>
       <td><input type="text" value="<?php echo $row[$accna];?>" id="cop<?php echo $row[$id];?>" style="background: transparent; border: 0px; outline: none; width: 100%; text-align: center;"> <i class="fa fa-copy" id="coy<?php echo $row[$id];?>"  title="copy link"></i></td>
       <td><?php echo $row[$bank];?></td>
       <td><?php echo $row[$date];?></td>
 <td><font color="red"><?php echo $row[$status];?></font></td>
       <td><form id='frm<?php echo $row[$id];?>' method='post'>

<button type="submit" class="btn<?php echo $row[$id];?>"> Confirm </button>
<input type="hidden" name="id" value="<?php echo $row[$id];?>">
<input type="hidden" name="email" value="<?php echo $row['email'];?>">
<input type="hidden" name="coin" value="<?php echo $row['coin'];?>">
<input type="hidden" name="wallet" value="<?php echo $row['wallet'];?>">
<input type="hidden" name="amount" value="<?php echo $row['amount'];?>">
<input type="hidden" name="name" value="<?php echo $row['name'];?>">
</form>
<div class="loader<?php echo $row[$id];?>" style=" display: none;"><img src="pix/loading51.gif" class="load_in" style="width:30px;"></div><div class="msg<?php echo $row[$id];?>"></div>

       </td>
       <td><form id='decl<?php echo $row[$id];?>' method='post'>

<button type="submit" class="btnd<?php echo $row[$id];?>" onclick="return(conffax())"> Decline </button>
<input type="hidden" name="id" value="<?php echo $row[$id];?>">
<input type="hidden" name="amount" value="<?php echo $row['amount'];?>">
<input type="hidden" name="user_id" value="<?php echo $row['user_id'];?>">
</form></td>

<td><form id='dele<?php echo $row[$id];?>' method='post'>

<button type="submit" class="btndel<?php echo $row[$id];?>" onclick="return(conffax())"> Delete </button>
<input type="hidden" name="id" value="<?php echo $row[$id];?>">
</form></td>
       
       </tr><?php } 
      echo "</table>";
      echo "</div>";
}

public function confirm_withdrawal($tb,$id,$idd,$status,$active){
    $con=$this->connect();

    $up="update $tb set 

    $status='$active' where $id=$idd";
    $sql=$con->query($up);
    if($sql){
        echo 1;
    }
    else{
        echo "Confirming payment failed";
    }
}



public function pay_user_bonus($tb,$name,$amount,$id,$status,$active,$date,$accno,$accna,$bank){
    $con=$this->connect();

    $sel="select * from $tb where $status='$active'";
    $sql=$con->query($sel);
    echo "<div class='table_control'>";
    //echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='0' width='100%' id='tb_trad' border='0'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
<th>Name</th>
<th>Amount</th>
<th>Coin</th>
<th>Wallet Address</th>
<th>Network</th>
<th>Date </th>
<th>Status </th>
<th></th>
</tr>


    ";
    $sn=1;
while($row=$sql->fetch_assoc()){?>

    <script type="text/javascript">
        
//update wallet
$("#frm<?php echo $row[$id];?>").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "comfirm_with_script_bonus.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".btn<?php echo $row[$id];?>").html("please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".btn<?php echo $row[$id];?>").attr("disabled",true);
    $(".loader<?php echo $row[$id];?>").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg<?php echo $row[$id];?>").fadeIn(2000);
      $(".msg<?php echo $row[$id];?>").html('payment confirmed...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader<?php echo $row[$id];?>").hide(10);

             setTimeout(function(){$(".main").load('pay_withdrawal_bonus.php')},2000);
            }
            else{ 
              
          $(".msg<?php echo $row[$id];?>").fadeIn(2000);
          $(".msg<?php echo $row[$id];?>").css("background-color","red");
      $(".msg<?php echo $row[$id];?>").html(data);
  $(".btn<?php echo $row[$id];?>").html('Confirm').css({"opacity":"1","cursor":"pointer"});
  $(".loader<?php echo $row[$id];?>").hide(10);
  $(".btn<?php echo $row[$id];?>").attr("disabled",false);
  setTimeout(function(){$(".msg<?php echo $row[$id];?>").fadeOut(2000)},3000);
}
        }
           
     });
  });

$("#coy<?php echo $row[$id];?>").click(function(){
var copy=document.getElementById('cop<?php echo $row[$id];?>');
copy.select();
document.execCommand('copy');
$(".msg<?php echo $row[$id];?>").fadeIn(1000);
   $(".msg<?php echo $row[$id];?>").html('Copied');
   
$(".msg<?php echo $row[$id];?>").css({"background-color":"rgba(0,0,0,0.9)","color":"white","border-radius":"20px"});
   setTimeout(function(){$(".msg<?php echo $row[$id];?>").fadeOut(2000)},3000);
});
    </script>
    <style>
.msg<?php echo $row[$id];?>{
    width: 100%;
    border-radius: 20px;
    padding: 10px;
    color: white;
    font-weight: bold;
    font-family: arial;
    display: none;
    margin: auto;
    text-align: center;
}
    </style>
    <tr align="center">
        <td><?php echo $sn++;?></td>
        <td><?php echo $row[$name];?></td>
       <td>$<?php echo $row[$amount];?></td>
       
       <td><?php echo $row[$accno];?></td>
       <td><input type="text" value="<?php echo $row[$accna];?>" id="cop<?php echo $row[$id];?>" style="background: transparent; border: 0px; outline: none; width: 100%; text-align: center;"> <i class="fa fa-copy" id="coy<?php echo $row[$id];?>"  title="copy link"></i></td>
       <td><?php echo $row[$bank];?></td>
       <td><?php echo $row[$date];?></td>
 <td><font color="red"><?php echo $row[$status];?></font></td>
       <td><form id='frm<?php echo $row[$id];?>' method='post'>

<button type="submit" class="btn<?php echo $row[$id];?>"> Confirm </button>
<input type="hidden" name="id" value="<?php echo $row[$id];?>">
<input type="hidden" name="email" value="<?php echo $row['email'];?>">
<input type="hidden" name="coin" value="<?php echo $row['coin'];?>">
<input type="hidden" name="wallet" value="<?php echo $row['wallet'];?>">
<input type="hidden" name="amount" value="<?php echo $row['amount'];?>">
<input type="hidden" name="name" value="<?php echo $row['name'];?>">
</form>
<div class="loader<?php echo $row[$id];?>" style=" display: none;"><img src="pix/loading51.gif" class="load_in" style="width:30px;"></div><div class="msg<?php echo $row[$id];?>"></div>

       </td></tr><?php } 
      echo "</table>";
      echo "</div>";
}

public function confirm_withdrawal_bonus($tb,$id,$idd,$status,$active){
    $con=$this->connect();

    $up="update $tb set 

    $status='$active' where $id=$idd";
    $sql=$con->query($up);
    if($sql){
        echo 1;
    }
    else{
        echo "Confirming payment failed";
    }
}


public function change_pass_function_ad($tb,$id,$idd,$pass_field,$pass){
    $con=$this->connect();

    $up="update $tb set 
    $pass_field='$pass' where $id=$idd";
    $sem=$con->query($up);

    if($sem){
       
        echo 1;
    }

else{
    echo "Password change failed";
}
}


public function view_msg($tb,$name,$phone,$email,$date,$msg,$id){
    $con=$this->connect();

    $sel="select * from $tb ORDER BY $id DESC";
    $sql=$con->query($sel);
    echo "<div class='table_control'>";
    //echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
<th>Sender</th>
<th>phone</th>
<th>Email</th>
<th>Date</th>
<th>Message</th>
</tr>


    ";
    $sn=1;
while($row=$sql->fetch_assoc()){

    echo "<tr align='center' style='font-size:12px;font-weight:bold;font-family: microsoft new tai lue;'><td>".$sn++."</td><td>".$row[$name]."</td><td>".$row[$phone]."</td><td>".$row[$email]."</td><td>".$row[$date]."</td><td>".$row[$msg]."</td></tr>";
}
echo "</table>";
echo "</div>";
}


public function trading_history_ad($tb,$name,$status,$active,$traid,$amount,$percent,$acrued,$profit,$days,$start,$end){
    $con=$this->connect();

    $sel="select * from $tb";
    $sql=$con->query($sel);
    echo "<div class='table_control'>";
    //echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
    <th>Name</th>
<th>Investment ID</th>
<th>Amount Invested</th>
<th>% ROI</th>
<th>ROI</th>
<th>Start Date</th>
<th>End Date</th>
<th>Status</th></tr>


    ";
    $sn=1;
while($row=$sql->fetch_assoc()){

    echo "<tr align='center' style='font-size:12px;font-weight:bold;font-family: microsoft new tai lue;'><td>".$sn++."</td>
    <td>".$row[$name]."</td>
    <td>".$row[$traid]."</td>

    <td>$".round($row[$amount],3)."</td><td>$".round($row[$percent],3)."</td><td>$".number_format($row[$acrued])."</td><td>".$row[$start]."</td><td>".$row[$end]."</td><td><font color='green'>".$row[$status]."</font></td></tr>";
}
echo "</table>";
echo "</div>";
}


public function mining_history_ad($tb,$name,$status,$active,$traid,$amount,$percent,$acrued,$profit,$days,$start,$end){
    $con=$this->connect();

    $sel="select * from $tb";
    $sql=$con->query($sel);
    echo "<div class='table_control'>";
    //echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
    <th>Name</th>
<th>Mining ID</th>
<th>Amount Invested</th>
<th>2% Daily profit</th>
<th>Accrued Profit</th>
<th>Profit + Capital</th>
<th>Day(s) Traded</th>
<th>Start Date</th>
<th>End Date</th>
<th>Status</th></tr>


    ";
    $sn=1;
while($row=$sql->fetch_assoc()){

    echo "<tr align='center' style='font-size:12px;font-weight:bold;font-family: microsoft new tai lue;'><td>".$sn++."</td>
<td>".$row[$name]."</td>
    <td>".$row[$traid]."</td><td>".number_format($row[$amount])."</td><td>".number_format($row[$percent])."</td><td>".number_format($row[$acrued])."</td><td>".number_format($row[$profit])."</td><td>".$row[$days]."</td><td>".$row[$start]."</td><td>".$row[$end]."</td><td><font color='green'>".$row[$status]."</font></td></tr>";
}
echo "</table>";
echo "</div>";
}


public function deposit_history_ad($tb,$name,$date,$amount,$status){
    $con=$this->connect();

    $sel="select * from $tb ";
    $sql=$con->query($sel);
    echo "<div class='table_control'>";
    //echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
    <th>Name</th>
<th>Amount </th>
<th>Date </th>
<th>Status</th></tr>



    ";
    $sn=1;
while($row=$sql->fetch_assoc()){

    echo "<tr align='center' style='font-size:12px;font-weight:bold;font-family: microsoft new tai lue;'><td>".$sn++."</td>
<td>".$row[$name]."</td>
    <td>$".round($row[$amount],3)."</td><td>".$row[$date]."</td><td><font color='red'>".$row[$status]."</font></td></tr>";
}
echo "</table>";
echo "</div>";
}

public function registere_users($tb){
    $con=$this->connect();

    $sel="select * from $tb";
    $sql=$con->query($sel);
    $num=$sql->num_rows;
    echo $num;
}

public function funding_users($tb,$status,$active){
    $con=$this->connect();

    $sel="select * from $tb where $status='$active'";
    $sql=$con->query($sel);
    $num=$sql->num_rows;
    echo $num;
}

public function update_msg($tb,$status,$complete){
    $con=$this->connect();
    $up="update $tb set 
    $status='$complete'";
    $sql=$con->query($up);
}


public function show_wallet_pay($tb,$network,$id,$idd,$coin,$amount,$addr,$status,$active,$idx){
    $con=$this->connect();

    $sel="select * from $tb where $id=$idd and $status='$active' ORDER BY $idx DESC  LIMIT 1";
    $sql=$con->query($sel);
    $row=$sql->fetch_assoc();
    echo "<div class='table_control'>";
    echo "<h2 align='center' style='color:brown'>Make payment to the wallet below</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'>";
  ?>

<tr style="font-family:arial;font-weight:bold "><td>Coin</td><td><?php echo $row[$coin];?></td></tr>

<tr style="font-family:arial;font-weight:bold "><td>Amount</td><td><input type="hidden" name="" id="amta" value="<?php echo $row[$amount];?>">$<?php echo number_format($row[$amount]);?><div id="dv_c"></div><input type="hidden" name="" id="price_hold" value="<?php if($row[$coin]=='BITCOIN'){echo "BTC";}elseif($row[$coin]=='BNB'){echo "BNB";} elseif($row[$coin]=='DOGECOIN'){echo "DOGE";} elseif($row[$coin]=='USDT'){echo "USDT";} elseif($row[$coin]=='TRON'){echo "TRX";}?>"></td></tr>
<tr style="font-family:arial;font-weight:bold ">
<td>Wallet Address</td><td><input type='text' value='<?php echo $row[$addr];?>'  class='txt' id='copyx' style='color:black;width:100%; font-weight:bold; overflow:hidden' readonly><br><button type='button' id='cox'>Copy</button><div class='msgc' style='display:none'></div></td></tr>
<tr style="font-family:arial;font-weight:bold ">
<td>Network</td><td><?php echo $row[$network];?></td></tr>
<tr >
<td align="center" colspan="2"><br><br><button type="button" onclick="window.location='dashboard'" class="back">Done</button></td></tr>

</table>
</div>

 <script>
$(document).ready(function(){

   $("#cox") .click(function(){
var cop=document.getElementById('copyx');
cop.select();
document.execCommand('copy');
$(".msgc").fadeIn(2000);
$(".msgc").html('Address Copied');
$(".msgc").css({"background-color":"rgba(0,0,0,0.9)","color":"white","border-radius":"20px","padding":"6px","text-align":"center"})
setTimeout(function(){$(".msgc").fadeOut(2000)},3000);

   });
});
   </script>
   <?php
}

public function transfer_to_wallet($tb,$td,$id,$idd,$amount,$wallet,$idx,$idxc,$ocr){

    $con=$this->connect();
    $up="update $tb set 
    $wallet=$wallet+$amount where $id=$idd";

    $sql=$con->query($up);

    if($sql){

        $upa="update $td set 
        $ocr=$ocr-$amount where $idx=$idxc";
        $sem=$con->query($upa);
        if($sem){
            echo 1;
        }else{
            echo "Transfer failed";
        }
    }


}
public function deletex($tb,$id,$idd){
    $con=$this->connect();
    $del="delete from $tb where $id=$idd";
    $sql=$con->query($del);

    if($sql){
        echo 1;
    }
    else{
        echo "Delete failed";
    }
}
public function decline_withdrawal($tb,$id,$idd,$idw,$amount,$wallet,$tw,$withd){

    $con=$this->connect();

    $up="update $tb set 
    $wallet=$wallet+$amount,$withd=$withd-$amount where $id=$idd";
    $sql=$con->query($up);
    if($sql){

        $del="delete from $tw where $id=$idw";
        $result=$con->query($del);
        if($result){
            echo 1;
        }
        else{
            echo "decline failed";
        }
    }
}

public function delete_w($tb,$id,$idd){
    $con=$this->connect();

    $del="delete from $tb where $id=$idd";
    $sql=$con->query($del);
    if($sql){
        echo 1;
    }
    else{
        echo "Delete failed";
    }
}

public function del_all($tb,$status,$active){
    $con=$this->connect();
    $del="delete from $tb where $status='$active'";
    $sql=$con->query($del);

    if($sql){
        echo 1;
    }
    else{
        echo "Deleting failed";
    }
}
public function announcement($tb,$msg,$fields,$values,$empty,$post,$tm,$ana){
    $con=$this->connect();

    $sel="select * from $tb";
    $sql=$con->query($sel);
    if($sql->num_rows<=0){

    $inser_field=implode(",", $fields);
$inser_values=implode('","',$values);
$insert='insert into '.$tb.'  ('.$inser_field. ') values("'.$inser_values.'")';

$result=$con->query($insert);
if($result){
    $upx="update $tm set 
$ana=1";
$ex=$con->query($upx);
    echo 1;
}
else{
    echo "announcement failed";
}

}
else{
    $up="update $tb set 
    $msg='$post'";
    $res=$con->query($up);
    if($res){
         $upx="update $tm set 
$ana=1";
$ex=$con->query($upx);
        echo 1;
    }
    else{
        echo "announcement failed";
    }
}
}
public function show_announcement($tb,$id,$idd,$ana,$ta,$msg,$empty){
    $con=$this->connect();

    $sel="select * from $tb where $id=$idd and $ana=1";
    $sql=$con->query($sel);
    if($sql->num_rows>=1){

        $se="select * from $ta where $msg!='$empty'";
        $sem=$con->query($se);
         $row=$sem->fetch_assoc();
        if($sem->num_rows>=1){

            ?>
            <div class="show_ana">
                <div><i class="fa fa-bell" id="urma" style="color:red; font-size: 40px;"></i> 
                    <h3>Announcement!</h3>

                    <?php echo $row[$msg];?>
                    <form id='close_ana' method="post">
                        <button type="submit" class="back"  style="margin-bottom: 0px; margin-top: 5px;">Close</button>
                    </form>
                </div></div>
                <?php
    }
}
}

public function close_announcement($tb,$id,$idd,$ana,$empty){
    $con=$this->connect();
    $up="update $tb set 
    $ana='$empty' where $id=$idd";
    $sql=$con->query($up);

    if($sql){
        echo 1;
    }
else{
    echo "Network error";
}
}
public function show_announcement_pub($ta,$msg,$empty){
    $con=$this->connect();


        $se="select * from $ta where $msg!='$empty'";
        $sem=$con->query($se);
         $row=$sem->fetch_assoc();
        if($sem->num_rows>=1){

            ?>
            <div class="show_ana">
                <div><i class="fa fa-bell" id="urma" style="color:red; font-size: 40px;"></i> 
                    <h3>Announcement!</h3>

                    <?php echo $row[$msg];?><br>
                        <button type="submit" class="back" id="bakxx"  style="margin-bottom: 0px; margin-top: 5px;">Close</button>
                    
                </div></div>
                <?php
    }

}

public function delete_announce($tb){
    $con=$this->connect();
    $del="delete from $tb";
    $sql=$con->query($del);
    if($sql){
        echo 1;
    }
}
public function view_member_search($tb,$name,$phone,$email,$ref,$wallet,$refwallet,$date,$id,$search){
    $con=$this->connect();

    $sel="select * from $tb where $name LIKE '%$search%' or $phone LIKE '%$search%' or $email LIKE '%$search%'";
    $sql=$con->query($sel);
    if($sql->num_rows<1){
        echo "<font color='red' size='+1'>No record found</font>";
    }else{
    echo "<div class='table_control'>";
    //echo "<h2 align='center' style='color:brown'>Active Mining</h2>";
    echo "<table align='center' cellpadding='10' cellspacing='1' width='100%' id='tb_trad'>";
    echo "<tr style='font-size:12px;font-family: microsoft new tai lue;'>
    <th>S/N</th>
<th>Name</th>
<th>phone</th>
<th>Email</th>
<th>Wallet</th>
<th>Ref Bonus</th>
<th>Date </th>
<th></th>
<th></th></tr>


    ";
    $sn=1;
while($row=$sql->fetch_assoc()){

    echo "<tr align='center' style='font-size:12px;font-weight:bold;font-family: microsoft new tai lue;'><td>".$sn++."</td><td>".$row[$name]."</td><td>".$row[$phone]."</td><td>".$row[$email]."</td><td>$".number_format($row[$wallet])."</td><td>$".number_format($row[$refwallet])."</td><td>".$row[$date]."</td><td><a href='block_user_script?user=$row[$id]' onclick='return(show_diag())'><button  type='button'>"?><?php if($row['country']!=1){?>Block User<?php }else{ ?> Unblock User<?php } echo "</button></a></td><td><a href='access_script?user=$row[$id]' target='_blank'><button type='button'>Access Dashboard</button></a></td></tr>";
}
echo "</table>";
echo "</div>";
}
}
public function verify_email ($tb,$tp,$pin,$pina,$verify,$verify_value,$id,$idd){
    $con=$this->connect();

    $sel="select * from $tp where $pin='$pina' and used!='used'";
    $sql=$con->query($sel);
    if($sql->num_rows>=1){

       $update="update $tb set 
       $verify=$verify_value  where $id=$idd";
       $upa=$con->query($update);
       if($upa){
        echo 1;

        $del="update  $tp set 
        used='used' where  $pin='$pina'";
        $sdp=$con->query($del);


       }
       else{
        echo "verification failed";
       }
    }
    else{
        echo "Invalid verification code. please try again";
    }
}
 //last     
 }