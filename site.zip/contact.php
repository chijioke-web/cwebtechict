<script type="text/javascript" src="js/java3.js"></script>
<img src="pix/plot_wave_bg.png" class="wave">

<div class="abt_text"><span class="txp">Contact Us for Enquiry</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption2" style="color:white">Always Online</span></div>
<div class="contact">

		
<div class="add">
	<h2 >ADDRESS</h2>
		<div class="link" >
	
	<ul>
	<li><i class="fa fa-map-marker" id="fan"></i> 1 & 2/110 Chambers Road Altona North VIC 3025 Australia</li>
                     <li><a href="mailto:support@BitralaxFx.com"><i class="fa fa-envelope" id="fan"></i> support@BitralaxFx.com</a></li>

                 



	</ul>
	
</div>
	</div>

	<div class="form_con">
		<h3 align="center">Online Contact Form</h3>
		<form id="contact_forma">
		<div class="lform" style="text-align:center;" >

	<i class="fa fa-user" id="fap"></i>
<input type="text" name="name" class="txt" placeholder="Your name" autocomplete="off" required></div>

<div class="lform" style="text-align:center;" >

	<i class="fa fa-phone" id="fap"></i>
<input type="tel" name="phone" class="txt" placeholder="Mobile No" autocomplete="off" required></div>


<div class="lform" style="text-align:center;" >

	<i class="fa fa-google" id="fap" aria-hidden="true"></i>
<input type="email" name="email" class="txt" placeholder="Your email" autocomplete="off" required></div>


<div class="lform" style="text-align:center;" >

	<i class="fa fa-map-marker" id="fap"></i>
<input type="text" name="city" class="txt" placeholder="Your City" autocomplete="off" required></div>


<div class="lform" style="text-align:center;" >

	<i class="fa fa-envelope" id="fap" style="vertical-align: top; margin-top: 30px;"></i>
<textarea name="msg" class="txtz" placeholder="Your Message" autocomplete="off" required></textarea></div>




<div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" >Send Message</button><br><br> <br><br></div>

	

</div>
</form>


</div>
