<?php
require 'head_ex.php';
require 'member_head.php';
require 'update_wallet_user.php';
?>

<body onkeypress="return disableCtrlKeyCombination(event);" onkeydown="return disableCtrlKeyCombination(event);" class="body">
<div id="ba"><img id="loading" src="pix/loading51.gif" alt="loading" /></div>
	<div class="nav_area">
	<?php require 'nav_mem.php';?>
	</div>

	<div class="main" id="mem_content">
		
		<?php require'dash.php';?>

		<div id="load_trad_min"><?php require 'show_progress.php';?></div>
	</div>	

<img src="pix/plot_wave_bg.png" class="wave">
<?php require 'copyright2.php';?>

<?php 
$tb='member_tb';
$id='id';
$idd=$_SESSION['id'];
$ana='ana';
$ta='announcement_tb';
$msg='msg';
$empty='';
$obj->show_announcement($tb,$id,$idd,$ana,$ta,$msg,$empty);?>

</body>
