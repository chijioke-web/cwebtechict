

<script type="text/javascript" src="js/java2.js"></script>

<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$sel="select * from member_tb where id='".$_SESSION['id']."' and any1!='' and any2!='' and any3!=''";
$sql=$conn->query($sel);
$row=$sql->fetch_assoc();
if($sql->num_rows<1){
	echo '<script>alert("please link your bank account details");window.location="dashboard?#u/o/?/page=bank";</script>';
}else{
?>
<br><br><br>
<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue">Linked Account Details</h3>
		<div class="fieldset_contro">
		<fieldset>
			<legend>Account number</legend>
<?php echo $row['any1'];?>
		</fieldset>
		
		<fieldset>
			<legend>Account name</legend>
<?php echo $row['any2'];?>
		</fieldset>

		<fieldset>
			<legend>Bank name</legend>
<?php echo $row['any3'];?>
		</fieldset>

</div>

	

</div>
</form>

	</div>



</div>

<?php } ?>

