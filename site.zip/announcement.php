<script type="text/javascript" src="js/java2.js"></script>


<br><br><br>
<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Make Announcement</h3>
		<form id="announcement" method="post">
		


<div class="lform" style="text-align:center;" >

	<i class="fa fa-bell" id="fap" style="vertical-align: top; margin-top: 30px;"></i>
<textarea name="msg" class="txtz" placeholder="write your announcement" autocomplete="off" required></textarea></div>








<div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" id="reg_button" > <i class="fa fa-sign-in" id="uroo"> </i> Submit</button></form><br><br><br><form id="delete_anoun" method="post"><button type="submit" class="del_but">Delete Current Announcement</button></form><br> <br><br></div>

	<div  class="load_chat" style="width:100%"></div>

</div>


	</div>



</div>

