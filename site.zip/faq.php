<script type="text/javascript" src="js/java2.js"></script>


<script type="text/javascript">
	$(document).ready(function(){
	$(".ref_div").css("display","none");
});
	
</script>

<img src="pix/plot_wave_bg.png" class="wave">

<div class="abt_text"><span class="txp">Frequently Asked Questions</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption2" style="color:white">Bitralaxfx</span></div>
<div class="contact">

	<div class="terms">	


	
<h3 align="center" style="font-family: microsoft new tai lue">Frequently Asked Questions</h3>

<div class="faq">How much does it cost to register?<span class="spm"></span>
<div class="inner_dv">Registration is free</div>
</div>

<div class="faq">Is my money safe with Bitralaxfx? </span>
<div class="inner_dv">Yes, your money is safe with us. We secure all accounts with high-security encryption. </div>
</div>

<div class="faq">How long does it take for my deposit to reflect in my wallet?</span>
<div class="inner_dv">Your  deposit gets confirmed within 0-2hrs </div>
</div>

<div class="faq">Can i withdraw my affiliate bonus as soon as it reflects?
</span>
<div class="inner_dv">Your Referral bonus is withdrawable at $100 </div>
</div>

<div class="faq">What is the minimum investment amount?</span>
<div class="inner_dv">Minimum investment depends on the package/plan you chose. our starter plan has $100 as minimum investment</div>
</div>

<div class="faq">How long does it take before i can make withdrwal?</span>
<div class="inner_dv">Your profit and capital can be withdrawn after investment period. You can decide to reinvest</div>
</div>



</div>

</div>
