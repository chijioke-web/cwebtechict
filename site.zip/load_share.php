<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$up="update member_tb set 
show_w=0 where show_w=1";

$sql=$conn->query($up);

?>