<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$_SESSION['reset']=$_GET['r'];

if(isset($_SESSION['reset'])){

header("location:index?#u/o/?/page=reset_form");

}
?>