

       
$(document).ready(function(){



$(".ref_div").css("display","none");
$(".letter").css("display","none");
$(".link").css("display","none");

$("#txt").keyup(function(){

if($(this).val().length>=1){
    $(".showp").show(1);
}
else{
 $(".showp").hide(1);   
}
});

$("#txt2").keyup(function(){
if($("#txt").val() !=$("#txt2").val()){

    $(".showp2").html("Password does not match").css("color","red");
}
else{
 $(".showp2").html("Password matched").css("color","green");   
}
});

$(".ckbox").click(function(){
    if($("#txt").attr("type")=="password"){
      $("#txt").attr("type","text");
      $("#txt2").attr("type","text");
      $("#ckbox").html("Hide Password");
    }
    else{
        $("#txt").attr("type","password");
      $("#txt2").attr("type","password");
       $("#ckbox").html("Show Password");

    }
});


 $('#txt2').bind("cut copy paste",function(e) {
      e.preventDefault();
  });
 $('#txt').bind("cut copy paste",function(e) {
      e.preventDefault();
  });
 $('#txt3').bind("cut copy paste",function(e) {
      e.preventDefault();
  });

 $('#ref').bind("cut copy paste",function(e) {
      e.preventDefault();
  });



//signup
$("#reg_form").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "reg_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Registration was successful! proceed to verification').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);
$(".reg_but2").html('Register').css({"opacity":"1","cursor":"pointer"});
             setTimeout('window.location.href="verify_code_send";',2000); 
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Register').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });  

//verified
$("#verifyacc_form").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "verify_code_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("verifying...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('verification was successful!').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);
$(".reg_but2").html('Verify').css({"opacity":"1","cursor":"pointer"});
             setTimeout('window.location.href="dashboard";',2000); 
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Verify').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });  

//sigin
$("#login_form").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "login_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Login you in shortly').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);
$(".reg_but2").html('Login').css({"opacity":"1","cursor":"pointer"});
             setTimeout('window.location.href="dashboard";',2000); 
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Login').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  }); 

//fund wallet
$("#fund_form").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "fund_wallet_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Order Placed successfully').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);
$(".reg_but2").html('Fund Wallet').css({"opacity":"1","cursor":"pointer"});
$(".reg_but2").attr("disabled",true);
             setTimeout(function(){$(".load_chat").load('agent.php');$("#fund_form").fadeOut(100)},1000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Fund wallet').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  }); 




//transfer fund first step
$("#transfer_form").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "transfer_first_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Redirecting you to next step...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             setTimeout(function(){$(".main").load('otp.php')},1000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Transfer Fund').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });

  //transfer fund completed
$("#otp").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "transfer_script_completed.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Transfer was successful ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             //setTimeout(function(){$(".main").load('otp.php')},1000);
             setTimeout('window.location.href="dashboard";',2000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Proceed').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  }); 


  //start trading
$("#trading").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "trading_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('You have successfully placed a trade ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             //setTimeout(function(){$(".main").load('otp.php')},1000);
             setTimeout('window.location.href="dashboard";',2000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Start Trade').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });


  //start mining
$("#mining").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "mining_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('You have successfully started mining ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             //setTimeout(function(){$(".main").load('otp.php')},1000);
             setTimeout('window.location.href="dashboard";',2000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Start Mining').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });
  setInterval(function(){$("#avai").load('balance_get.php')},1000);  
  setInterval(function(){$("#avai2").load('balance_get_bonus.php')},1000); 
  setTimeout(function(){$("#lox").load('load_all_price.php');$("#loxp").val($("#lox").html())},1000); 
  setTimeout(function(){$("#loxb").load('load_all_price_bonus.php');$("#loxpb").val($("#loxb").html())},1000);   
     
$("#allxc").click(function(){
$("#amt_all").val($("#lox").html());

});


$("#allxcb").click(function(){
$("#amt_allb").val($("#loxb").html());

});


  //withdraw fund first step
$("#withdraw_wallet").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "withdraw_first.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Redirecting you to next step...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             setTimeout(function(){$(".main").load('otp_w.php')},1000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Withdraw').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });


  //withdraw completed
$("#otp_w").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "withdraw_complete_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('You have successfully placed a withdrawal request...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             setTimeout(function(){$(".main").load('widthdraw_history.php')},2000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Proceed').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });


//withdraw bonus first step
$("#withdraw_bonus").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "withdraw_first_bonus.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Redirecting you to next step...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             setTimeout(function(){$(".main").load('otp_b.php')},1000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Withdraw').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });


  //withdraw  bonus completed
$("#otp_b").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "withdraw_bonus_complete_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('You have successfully placed a withdrawal request...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             setTimeout(function(){$(".main").load('bonus_history.php')},2000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Proceed').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });


//verify bank
$("#verify").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "inde4bank.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("verifying...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('verification completed. please wait...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             setTimeout(function(){$(".main").load('up_bank.php')},2000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Verify account').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });


//update bank
$("#upbank").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "update_bank_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("linking account...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Acount details linked successfully. please wait...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             setTimeout(function(){$(".main").load('show_bank_details.php')},2000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Link account').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });

//change password
$("#pass_change_form").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "change_password_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Redirecting please wait...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             setTimeout(function(){$(".main").load('otp_p.php')},2000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Change Password').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });

//change password final
$("#otp_p").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "change_password_final_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('password changed successfully ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             //setTimeout(function(){$(".main").load('otp.php')},1000);
             setTimeout('window.location.href="dashboard";',2000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Proceed').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });

//send message by users
$("#support").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "support_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Message sent successfully ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             //setTimeout(function(){$(".main").load('otp.php')},1000);
             setTimeout('window.location.href="loga";',2000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Submit').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });
$(".valx").load('ref2.php').css({"color":"white","display":"none"});

    setTimeout(function(){$("#ref").val($(".valx").html())},2000);




//forgot password
$("#forgot").submit(function(e){
e.preventDefault();

  $.ajax({
          url: "forgot_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"wait"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Your password reset link has been sent to your email ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             $(".txt").val('');
             $(".reg_but2").html('Submit').css({"opacity":"1","cursor":"pointer"});
              $(".reg_but2").attr("disabled",false);
              setTimeout(function(){$(".msg").fadeOut(2000)},3000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Send Message').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });

//reset password final
$("#reg_form_reset").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "reset_script_final.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Password reset was successful. Redirecting to login ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             //setTimeout(function(){$(".main").load('otp.php')},1000);
             setTimeout('window.location.href="login_redirect";',2000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Reset').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  }); 

//sigin as admin
$("#login_form_add").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "login_add_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Login you in shortly').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);
$(".reg_but2").html('Login').css({"opacity":"1","cursor":"pointer"});
             setTimeout('window.location.href="admin";',2000); 
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Login').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  }); 

//change password final admin
$("#pass_change_form_ad").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "change_password_final_script_ad.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('password changed successfully ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             //setTimeout(function(){$(".main").load('otp.php')},1000);
             setTimeout('window.location.href="admin#u/o/?/page=change_password_ad";',2000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Change').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });
//delete all pending
$("#del_all").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "del_all.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".btn").html("deleting...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".btn").attr("disabled",true);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('deleted...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      

             setTimeout(function(){$(".main").load('fund_user_wallet.php')},1000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".btn").html('Delete All').css({"opacity":"1","cursor":"pointer"});
  
  $(".btn").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });

//broadcast announcement
$("#announcement").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "announ.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Announcement broadcasted ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             //setTimeout(function(){$(".main").load('otp.php')},1000);
             setTimeout('window.location.href="ana";',1000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Submit').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });

//delete announcement
$("#delete_anoun").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "delete_ana.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".del_but").html("Deleting...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".del_but").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Announcement deleted ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             //setTimeout(function(){$(".main").load('otp.php')},1000);
             setTimeout('window.location.href="ana";',1000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".del_but").html('Delete Current Announcement').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".del_but").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });
  setTimeout(function(){$("#show_block").load("show_block_code.php")},1000);
//last
});

function conffax(){
    var a=confirm("Are you sure you want to Proceed?");
    if(a==true){

    }else{

    }
    return a;
}
