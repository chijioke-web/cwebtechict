<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$field_data=array('id int(100) not null auto_increment primary key',
	'name varchar(100)not null',
'phone varchar(100)not null',
'email varchar(100)not null',
'password text not null',
'ref_email varchar(100)not null',
'address varchar(100)not null',
'wallet int(100)not null',
'withdrawal int(100)not null',
'ref_wallet int(100)not null',
'ref_widthdrawal int(100)not null',
'country varchar(100)not null',
'datex varchar(100)not null',
'any1 varchar(100)not null',
'any2 varchar(100)not null',
'any3 varchar(100)not null',
'paid varchar(100)not null',
'nation varchar(100)not null',
'ana varchar(99)not null',
'show_w int(99)not null',
'ref_id varchar(99)not null',
'verify varchar(99)not null'
);
$tb='member_tb';
$crt=$obj->create_table($tb,$field_data);

$first=clean($_POST['first']);
$last=clean($_POST['last']);
$email=clean($_POST['email']);
$pass=clean($_POST['password']);
$pass2=clean($_POST['pass']);
$address=clean($_POST['address']);
$name=ucfirst($last)." ".ucfirst($first);
$pass_hash=hash('sha256',$pass);
$ref_mail=clean($_POST['ref_email']);
$email_filed='email';
$phone=clean($_POST['phone']);
$date=date("d-m-Y");
$tel=clean($_POST['tel_code']);
$ph=substr($phone, 1);
$pho=$tel.$phone;
$country=clean($_POST['country']);
function password(){
    $le=7;
    $cha='01234567892345678901234567890';
    $mai="";
    for($i=0;$i<$le;$i++){
    @$mai.=$cha[mt_rand(0,strlen($cha))];
    }
    return $mai;
    }
    $passx=password();
    $dd='BTRA';
    $pay=$dd.$passx;

$fields=array(
'name',
'phone',
'email',
'password',
'ref_email',
'address',
'wallet',
'withdrawal',
'ref_wallet',
'ref_widthdrawal',
'country',
'datex',
'any1',
'any2',
'any3',
'paid',
'nation',
'ana',
'show_w',
'ref_id',
'verify'

);

$values=array(
$name,
$pho,
$email,
$pass_hash,
$ref_mail,
$address,
'0',
'0',
'0',
'0',
'Nigeria',
$date,
'',
'',
'',
'',
$country,
'',
'0',
$pay,
''
);

$reg=$obj->register($tb,$pass,$pass2,$email,$ref_mail,$email_filed,$fields,$values,$name,$phone);

?>