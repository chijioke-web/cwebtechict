


<br><br><br>
<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> My Referrals</h3>
		<form id="otp_p" method="post">
		


<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';



        $obj->show_reff('member_tb','ref_email',$_SESSION['ref_id'],'phone','name','email');

    


?><br> <br><br></div>

	

</div>
</form>

	</div>



</div>

