<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';
$id='id';
$idd=clean($_POST['user_id']);
$idw=clean($_POST['id']);
$amount=clean($_POST['amount']);
$wallet='wallet';
$tw='withdraw_tb';
$withd='withdrawal';
$obj->decline_withdrawal($tb,$id,$idd,$idw,$amount,$wallet,$tw,$withd);