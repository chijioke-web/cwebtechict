<script type="text/javascript" src="js/java2.js"></script>


<br><br><br>
<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Start Investment <span id="show_pert"></span></h3>
		<form id="trading" method="post" name="tradingx">
		
<div class="lform" style="text-align:center;" >
		<select name="plan" class="txt" style="color:white;background:black" required onchange="invest_nwx()">
			<option value="" >Select Plan</option>
			<option value="Starter">Starter</option>
			<option value="Basic">Basic</option>
			<option value="Gold">Gold</option>
			

		</select>
	</div>

<div class="lform" style="text-align:center;" >

	<i class="fa fa-dollar" id="fap" aria-hidden="true"></i>
<input type="number" name="amt" class="txt" placeholder="Amount" autocomplete="off" required min="10" max="10000000000000000000000"  value="0"></div>








<div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" id="reg_button" > <i class="fa fa-sign-in" id="uroo"> </i> Invest Now</button><br> <br><br></div>

	<div  class="load_chat" style="width:100%"></div>

</div>
</form>

	</div>



</div>

