<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';
$tp='pin';
$id='id';
$idd=$_SESSION['id'];
$pass_field='password';
$pin_f='pin';
$used='used';
$empty='';
$us='used';

$pin=clean($_POST['otp']);
$pa=$_SESSION['passx'];
$pass=hash('sha256',$pa);
$log=$obj->change_pass_function($tb,$id,$idd,$pass_field,$pass,$pin_f,$pin,$tp,$used,$empty,$us);

?>