<?php
echo "Crypto Mining, Crypto TRADING, Investment, Coin Redistribution";
?>