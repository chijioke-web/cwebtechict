


<br><br><br>
<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Mining History</h3>
		<form id="otp_p" method="post">
		


<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';



       $obj->mining_history('mining_tb','user_id',$_SESSION['id'],'status','active','trad_id','amount','percent','acrud_profit','profit','days_with','dat_inv','date_rec');

    


?><br> <br><br></div>

	

</div>
</form>

	</div>



</div>

