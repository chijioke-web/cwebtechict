<?php 

require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
echo 'Available Balance: ';
$obj->wallet_amount('member_tb','id',$_SESSION['id'],'wallet');

?>