<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$selc="select * from trading_tb where user_id='".$_SESSION['id']."' and status='active'";
$sx=$conn->query($selc);



		$obj->show_reff('member_tb','ref_email',$_SESSION['email'],'phone','name');

	


?>