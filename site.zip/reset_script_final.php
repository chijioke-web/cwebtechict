<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';

$em=$_SESSION['reset'];
$email='email';
$pass_f='password';
$pass=clean($_POST['password']);
$pa=clean($_POST['pass']);
$password=hash('sha256',$pass);
$log=$obj->reset_password_final($tb,$email,$pass_f,$em,$pass,$pa,$password);


?>