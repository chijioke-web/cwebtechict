<script type="text/javascript" src="js/java2.js"></script>


<script type="text/javascript">
	$(document).ready(function(){
	$(".ref_div").css("display","none");
});
	
</script>

<img src="pix/plot_wave_bg.png" class="wave">

<div class="abt_text"><span class="txp">Privacy Policy</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption2" style="color:white">BitralaxFx</span></div>
<div class="contact">

	<div class="terms">	


	
<h3 align="center" style="font-family: microsoft new tai lue">Privacy Policy</h3>


<p>Welcome to BitralaxFx!. We understand that privacy online is important to users of our Site, especially when conducting business.This statement governs our privacy policies with respect to those users of the Site (“Visitors”) who visit without transacting business and Visitors who register to transact business on the Site and make use of the various services offered by BitralaxFx(collectively, “Services”) (“Authorized Customers”).
and operates the website https://www.BitralaxFx.com (hereinafter referred to as “this Website” or “the Website”), which is a platform dedicated to the transaction of digital mining and the provision of related services.</p>

<p>1.1.2  “Digital Mining ” refers to a digital representation of value (also referred to as “cryptomining ,” “virtualmining ,” ,”“crypto token,” which is based on the cryptographic protocol of a computer network that may be (i) centralized or decentralized, (ii) closed or open-source, and (iii) used as a medium of exchange and/or store of value.</p>

<p>1.1.3  “User” refers to all natural persons who log onto this Website.  For the convenience of wordings in this Policy, users are also referred to as “you” or any other applicable forms of the second-person pronouns. </p>  

<p>1.1.4  “User Account” refers to a user-accessible account offered via the Company’s services, including without limitation, the hosted wallet services where Digital Mining are done.</p> 

<p>1.1.5  “Personal Information” or “Personal Data” or “your data” refers to any information relating to you as an identified or identifiable natural person, including but not limited to your name, an identification number, location data, or an online identifier or to one or more factors specific to the physical, economic, cultural or social identity of you as a natural person. </p>


<h3>PURPOSE</h3>

<p>2.1  This Privacy Policy explains what you can expect from BitralaxFx in protecting your Personal Information, and what we need from you to ensure such efforts succeed.  Please read this Policy carefully as it is legally binding when you use any and all BitralaxFx services, regardless of how you access or use them, including through mobile devices or other portals. </p> 

<h3>COLLECTION OF PERSONAL INFORMATION </h3>

<ul>
	3.1  BitralaxFx may collect and use the following Personal Information from you to provide services:

<li>Full legal name;</li>
<li>Home address, including country of residence;</li>
<li>Email address;</li>
<li>Mobile phone number;</li>
<li>Crypto wallet address</li>
<li>Username </li></ul>

<p>Personal Information you provide while using BitralaxFx services may be retained, even if your registration is left incomplete or abandoned. </p>  
<p>
If you are providing Personal Information of any individual other than yourself to us during your use of BitralaxFx website and BitMart services, you promise that you have obtained consent from such individual to disclose his/her Personal Information to us, as well his/her consent to our collection, use and disclosure of such Personal Information under this Privacy Policy.  </p>   
<ul>
BitralaxFx uses the Personal Information we collect for the following carefully considered business purposes, which also benefit our Users: 

<li>To provide you with our services through our website;</li>

<li> identify and confirm your identity when you use our website;</li>

<li>To personalize your experience while using BitralaxFx services;</li></ul>

<p>To facilitate transactions (your information, whether public or private, will not be sold, exchanged, transferred, or otherwise provided to any other company on any grounds without your consent, except for where doing so is solely and expressly for the purpose of completing the transaction per your instruction);</p>

<p>To regularly send e-mail and other kinds of communications or notifications (the email address that you provide while using BitralaxFx services may be used to receive updates to your transactions and updates, newsletters, new product or service information, and other kinds of communication, unless BitralaxFx receives specific instructions from you regarding your email preference);</p>

<p>To meet other purposes as specified in the User Agreement listed on BitralaxFx website and any and all legal means adopted for satisfying such purposes. </p>


<p>4.2  BitralaxFx does not sell, trade, transfer Personal Information to external parties, or allow external parties to do so on BitralaxFx website.  However, to the extent necessary for 1) proper functioning of BitralaxFx website and improvement of BitralaxFx services 2) compliance with any of the applicable laws, regulations, rules or any order of courts or other competent authorities or 3) due protection of the rights, property, or safety of us or other persons, the following parties shall be excluded from such promise: our traders and trusted third party vendors we engage to help us operating our website, managing our business, or providing services directly and indirectly to the Users, provided that such parties understand and agree to keep such Personal Information confidential. Nevertheless, your Personal Information will not be provided to external parties for marketing, advertising or other purposes, unless an authorization is directly obtained from you.   
</p>

<h3>PROTECTION OF PERSONAL INFORMATION</h3>
<p>
5.1  We adopt appropriate physical, electronic, technical and managerial measures to protect and safeguard your Personal Information.  We will, to the greatest extent possible, ensure that any Personal Information collected through our Website shall be free from being subject to the nuisance by any external parties.  The security measures that we may take include but are not limited to: </p>  

<p>Physical measures: Records of your Personal Information will be stored in a properly locked place against loss, theft, unauthorized use, disclosure, or modification.
Electronic measures: Electronic data that contain your Personal Information will be stored in properly encrypted computer systems and storage media that are subject to strict login/access restrictions.
Technical measures: Proper encryption techniques, including but not limited to Secure Socket Layer Encryption technology, may be used to protect your Personal Information.
Managerial measures: Only staff members duly authorized by us can access your Personal Information, and these staff members are duly trained and monitored to comply with our internal code of ethics concerning personal data protection.  </p>
Other measures that we deem necessary in ensuring the safety of your Personal Information.
<p>5.2  To help us protect your Personal Information, you should maintain the secrecy of your logon ID and password you may have set up while using BitralaxFx services.  We shall not be held liable for damage or loss of any kind caused directly or indirectly by your own failure in maintaining the secrecy of your logon information.</p> 


<h3>DATA RETENTION</h3>

6.1  As BitralaxFx and its traders may be subject to various legal, compliance and reporting requirements, including but not limited to national AML requirements, we record and store some of your personal and transactional data beyond the closure of your User Account.  Your Personal Information will only be accessed internally on a need to know basis, and it will only be accessed or processed if absolutely necessary.  We will constantly monitor and delete data that is no longer required by any relevant law or jurisdiction in which we operate.

<h3>7. COOKIES</h3>

7.1  When you use BitralaxFx services, we may make use of the standard practice of placing tiny data files called cookies, flash cookies, pixel tags, or other tracking tools (hereinafter referred to as “Cookies”) on your computer or other devices used to engage BitralaxFx services.  We use Cookies to (i) help us recognize you as a customer, collect information about your use of BitralaxFx services to better customize our services and content for you, and to collect information about your computer or other access devices as part to ensure our compliance with regulatory obligations and to (ii) ensure that your account security has not been compromised by detecting irregular or suspicious account activities.  We use both session and persistent Cookies.  Session Cookies expire when you log out of your User Account or close your browser.  Persistent Cookies remain on your computer or mobile device until deleted or otherwise expire.  Most web browsers are set to accept Cookies by default.  You are free to decline most of our session Cookies for each browser or browser add-on permit on each device you use to surf our Website, but choosing to remove or disable our Cookies may interfere with your use and functionality of BitralaxFx services.

<h3>8. RIGHTS WITH RESPECT TO YOUR PERSONAL INFORMATION</h3>

8.1  Depending on the jurisdiction, you may have the right to access, correct, delete, or restrict the use of your Personal Information covered by this Privacy Policy.  Depending on the jurisdiction, you may also have the right to request that we refrain from processing your Personal Information.  Please bear in mind that if you choose to exercise such rights this may affect our ability to provide BitralaxFx services.  For inquiries about your Personal Information, please contact us by sending an email to support@BitralaxFx.com and BitralaxFx will make reasonable efforts to accommodate your request.  However, we also reserve the right to impose certain restrictions and requirements on such requests, if allowed or required by applicable laws.  Please also note that it may take some time to process your request, consistent with applicable law.

<h3>9. MODIFICATION</h3>

9.1  At sole discretion of the Company, we may amend this Privacy Policy from time to time by posting the amended version on our Website, publishing the effective date of the amended version, and highlighting amendments made.  We may announce such amendments to you via email, but you are strongly encouraged to review such Policy regularly.  If you do not agree with any of the amendments made, you shall stop using BitralaxFx services immediately.  Should you continue to use BitralaxFx services after we release an amended version of this Policy, your continued visit to BitralaxFx website shall indicate and show that you agree to the update and agree to comply with the updated Privacy Policy.

<h3>10. CONTACT US</h3>
<p>
10.1  If you have any requests, comments, or questions, please contact us via email to support@BitralaxFx.com, which is the sole official email through which we communicate with our Users.  BitralaxFx will not be responsible for your failure in using effective contact channels, or any act or omission related. 
</p>
<p>10.2  We will only publish announcements and information on the basis of the valid and effective contact information on our Website or post announcements on our Website; therefore, we shall not be held liable for any loss arising from your trust in the information that has not been obtained through the above-mentioned means or methods.</p>
</div>

</div>
