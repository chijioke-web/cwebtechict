<?php
require 'head_ex.php';
require 'front_head.php';
?>

<body onkeypress="return disableCtrlKeyCombination(event);" onkeydown="return disableCtrlKeyCombination(event);">
<div id="ba"><img id="loading" src="pix/loading51.gif" alt="loading" /></div>
	<div class="main">
		


<?php require 'login_add.php';?>



	</div>

	<?php require 'footer_script.php';?>
	

	<?php require 'aobfooter.php';?>
	