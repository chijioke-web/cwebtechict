<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='funding_tb';
$id='id';
$idd=clean($_POST['idel']);

$obj->deletex($tb,$id,$idd);