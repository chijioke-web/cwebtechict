<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';

$idd=clean($_GET['user']);
$id='id';
$name='name';
$email='email';
$log=$obj->access_dashboard($tb,$id,$idd,$name,$email);

?>