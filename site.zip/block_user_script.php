<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';

$idd=clean($_GET['user']);
$id='id';
$block='country';
$block_value=1;
$blo='Nigeria';
$log=$obj->block_user($tb,$id,$idd,$block,$block_value,$blo);

?>