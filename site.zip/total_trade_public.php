<?php
require 'main_class.php';
$obj=new WEB_CONTROL();


 $obj->total_trad_min_public('trading_tb','total','amount','id',1500000);


?>