<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='admin_tb';

$email=clean($_POST['email']);
$email_field='email';
$password='password';
$pas=clean($_POST['password']);
$pass=hash('sha256',$pas);
$log=$obj->login_ad($tb,$email,$email_field,$password,$pass);

?>