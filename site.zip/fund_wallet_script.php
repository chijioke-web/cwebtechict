<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$field_data=array('id int(100) not null auto_increment primary key',
	'name varchar(100)not null',
'phone varchar(100)not null',
'email varchar(100)not null',
'amount varchar (100) not null',
'ref varchar(100)not null',
'user_id varchar(100)not null',
'datex varchar(100)not null',
'any varchar (100)not null',
'coin varchar(99) not null',
'wallet_add text not null',
'network varchar(99) not null',
'pay_from text not null'
);
$tb='funding_tb';
$crt=$obj->create_table($tb,$field_data);

$amt=clean($_POST['amt']);
$name=$_SESSION['name'];
$email=$_SESSION['email'];

$phone=$_SESSION['phone'];
$date=date("d-m-Y");
$id=$_SESSION['id'];
$ref=$_SESSION['ref'];
$coin=clean($_POST['coin']);
$wallet_add=clean($_POST['wallet_add']);
$network=clean($_POST['network']);
$pay_from=clean($_POST['pay_from']);
 require 'phpmailer/send_deposit.php';
$fields=array(
'name',
'phone',
'email',
'amount',
'ref',
'user_id',
'datex',
'any',
'coin',
'wallet_add',
'network',
'pay_from'


);

$values=array(
$name,
$phone,
$email,
$amt,
$ref,
$id,
$date,
'pending',
$coin,
$wallet_add,
$network,
$pay_from

);

$reg=$obj->fund_wallet($tb,$fields,$values);

?>