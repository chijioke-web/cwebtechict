<?php 

if(!isset($_SESSION['idx'])){

	header("location:logout3.php");
}