<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';
$email='email';
$uer_input= clean($_GET['email']);
$ck=$obj->check_email($tb,$email,$uer_input);

?>