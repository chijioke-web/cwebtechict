<script type="text/javascript" src="js/java2.js"></script>


<img src="pix/plot_wave_bg.png" class="wave">

<div class="abt_text"><span class="txp">Forgot Password</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption2" style="color:white">100% Secure</span></div>
<div class="contact">

		


	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Password Recovery</h3>
		<form id="forgot" method="post">
		


<div class="lform" style="text-align:center;" >

	<i class="fa fa-envelope" id="fap" aria-hidden="true"></i>
<input type="email" name="email" class="txt" placeholder="Enter your registerred email" autocomplete="off" required></div>







<div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" id="reg_button" > <i class="fa fa-sign-in" id="uroo"> </i> Submit</button><br> <br><br></div>

	

</div>
</form>

	</div>



</div>
