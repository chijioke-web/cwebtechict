<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';

$ema=clean($_POST['email']);
$email='email';
$log=$obj->forgot_password($tb,$email,$ema);

?>