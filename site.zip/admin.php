<?php
require 'head_ex.php';
require 'admin_head.php';

?>

<body onkeypress="return disableCtrlKeyCombination(event);" onkeydown="return disableCtrlKeyCombination(event);" class="body">
<div id="ba"><img id="loading" src="pix/loading51.gif" alt="loading" /></div>
	<div class="nav_area">
	<?php require 'nav_add.php';?>
	</div>

	<div class="main" id="mem_content">
		
		<?php require'view_member.php';?>
		
	</div>	

<img src="pix/plot_wave_bg.png" class="wave">
<?php require 'copyright2.php';?>

</body>
