<script type="text/javascript" src="js/java2.js"></script>


<br><br><br>
<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Fund Wallet</h3>
		  <div  class="load_chat" style="width:100%"></div>
		<form id="fund_form" method="post" name="coin_fund">
		


<div class="lform" style="text-align:center;" >

	<i class="fa fa-dollar" id="fap" aria-hidden="true"></i>
<input type="number" name="amt" class="txt" placeholder="Enter amount" autocomplete="off" required min="10" max="1000000000000"></div>

<center><font size="2" color="red" face="arial">*** Enter<span style="text-transform:lowercase"> YOUR WALLET  FROM WHICH PAYMENT  WILL BE MADE FROM***</span></font></center>
<div class="lform" style="text-align:center;" >

    <i class="fa fa-briefcase" id="fap" aria-hidden="true"></i>
<input type="text" name="pay_from" class="txt" placeholder="Enter wallet address you will pay from" autocomplete="off" required ></div>


<div class="lform" style="text-align:center;" >

	<i class="fa fa-wallet" id="fap" aria-hidden="true"></i>
<select name="coin" class="txt" required style="color: white; background:black" onchange="wallet_addx()">
	<option value="">Select Payment option</option>
<option value="BITCOIN">BITCOIN</option>
	<option value="BNB">BNB</option>
	<option value="TRON">TRON</option>
    <option value="USDT">USDT</option>
    <option value="ETH">ETHERUM</option>
    
</select>


</div>


<input type="hidden" name="wallet_add" class="txt" style="color:brown">
<input type="hidden" name="network" class="txt" style="color:brown">






<div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" id="reg_button" > <i class="fa fa-sign-in" id="uroo"> </i> Fund Wallet</button><br> <br><br></div>


</div>
</form>

	</div>



</div>
<script type="text/javascript">
	/*

	function wallet_addx(){
    var coin=document.coin_fund.coin.value;

    switch(coin){

        case"BITCOIN":
        document.coin_fund.wallet_add.value='bc1q9vjvaqlgkry70dyamndnsmwwha5kxulyfn0lrr';
        document.coin_fund.network.value='bitcoin';
        break;
        case"BNB":
         document.coin_fund.wallet_add.value='bnb16xaw4jntkvvpcysxlr6kg79tvt8jh805xr4qq5';
        document.coin_fund.network.value='Bep20';
        break;
        case"DOGECOIN":
         document.coin_fund.wallet_add.value='DLfkAxmHqzhWZgmNrgEXxGUBaSTS83bwK2';
        document.coin_fund.network.value='dogecoin';
        break;
        case"USDT":
         document.coin_fund.wallet_add.value='0xCB4c952335C0EAa07AF037336033119Add9a6f12';
        document.coin_fund.network.value='bep20';
        break;
        case"TRON":
         document.coin_fund.wallet_add.value='TQrbayojHHFVfHVybFsWJtSp4ZKhsip8QW';
        document.coin_fund.network.value='Tron(TRC20)';
        break;
        default:
        document.coin_fund.wallet_add.value='hello';
    }
}
*/
</script>