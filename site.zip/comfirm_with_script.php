<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='withdraw_tb';
$id='id';
$idd=clean($_POST['id']);
$status='status';
$active='completed';
$nama=clean($_POST['name']);
$coin=clean($_POST['coin']);
$walletax=clean($_POST['wallet']);
$emap=clean($_POST['email']);
$amounta=clean($_POST['amount']);
require 'phpmailer/withdrawal_confirmed.php';
$log=$obj->confirm_withdrawal($tb,$id,$idd,$status,$active);

?>