<?php
function clean($data){
	$obj=new WEB_CONTROL();
	$conn=$obj->connect();
	$data=trim($data);
	$data=stripslashes($data);
	$data=htmlentities($data);
	$data=htmlspecialchars($data);
	$data=mysqli_real_escape_string($conn,$data);
return $data;
}

