<div class="plans">


<div class="abt_text"><span class="txp" >Our Investment Plans</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption" >Profit Withdrawable when due</span></div>

<div class="step_control">


<div class="plan1">
<div class="in1"><img src="pix/package_icon_1.png" class="start_image"><br><span class="caption" style="color:black">STARTER</span></div>
<div class="inner1"><span class="captionxx">2.5%</span></div>

	<ul>
		<li>2.5% Daily Profit</li>
		<li>6 days Duration</li>
		<li>Instant Profit withdrawal after 24hrs</li>
		<li>10% Referral Bonus</li>
		<li>Minimum Investment: 100.00 USD</li>
		<li>Maximum Investment: 19,999.00 USD</li>
	</ul>

	<center><a href="#u/o/?/page=register" class="index"><button  id="plan_button1" type="submit">Sign Up</button></a></center>
</div>

<div class="plan2" >
<div class="in2"><img src="pix/package_icon_2.png" class="start_image"><br><span class="caption" style="color:black">BASIC</span></div>
<div class="inner2"><span class="captionxx">3%</span></div>

	<ul>
		<li>3%  daily Profit </li>
		<li>6 days duration</li>
		<li>Instant Profit withdrawal after 6 days</li>
		<li>10% Referral Bonus</li>
		<li>Minimum Investment: 20,000.00 USD</li>
		<li>Maximum Investment: 49,999.00 USD</li>
	</ul>

	<center><a href="#u/o/?/page=register" class="index"><button  id="plan_button2" type="submit">Sign Up</button></a></center>
</div>


<div class="plan3" >
<div class="in3"><img src="pix/package_icon_3.png" class="start_image"><br><span class="caption" style="color:black">GOLD</span></div>
<div class="inner3"><span class="captionxx">3.5%</span></div>

	<ul>
		<li>3.5% daily Profit</li>
		<li>6 days Duration</li>
		<li>Instant Profit withdrawal after 6 days </li>
		<li>10% Referral Bonus</li>
		<li>Minimum Investment: 50,000 USD</li>
		<li>Maximum Investment: Unlimied USD</li>
	</ul>

	<center><a href="#u/o/?/page=register" class="index"><button  id="plan_button3" type="submit">Sign Up</button></a></center>
</div>


</div>