<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$field_data=array('id int(100) not null auto_increment primary key',
	'msg text not null'
);
$tb='announcement_tb';
$crt=$obj->create_table($tb,$field_data);

$msg='msg';
$fields=array('msg');
$post=clean($_POST['msg']);
$values=array($post);
$empty='';
$tm='member_tb';
$ana='ana';
$obj->announcement($tb,$msg,$fields,$values,$empty,$post,$tm,$ana);