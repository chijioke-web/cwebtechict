<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$_SESSION['link']=$_GET['ref'];

header("location:index?#u/o/?/page=register");


?>