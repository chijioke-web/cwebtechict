<script type="text/javascript" src="js/java2.js"></script>


<br><br><br>


<?php

require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
function password(){
    $le=5;
    $cha='01234567892345678901234567890';
    $mai="";
    for($i=0;$i<$le;$i++){
    @$mai.=$cha[mt_rand(0,strlen($cha))];
    }
    return $mai;
    }
    $pass=password();
    $dd='BITRA';
    $pay=$dd.$pass;
$_SESSION['pay']=$pay;
$payx=$_SESSION['pay'];
$date=date("d-m-Y");
$tbx='pin';
$fields=array(
'pin',
'used',
'datex'
);
$values=array(

	$pay,
'',
$date
);
    $in=$obj->insert_value($tbx,$fields,$values);

//send email
    //message
    $na=$_SESSION['name'];
$emailx=$_SESSION['email'];

//Load Composer's autoloader
require 'phpmailer/send_otp_password.php';

/*

// Require the bundled autoload file - the path may need to change
    // based on where you downloaded and unzipped the SDK
    require  'twilio-php-main/src/Twilio/autoload.php';
    
    // Use the REST API Client to make requests to the Twilio REST API
    use Twilio\Rest\Client;
    
    // Your Account SID and Auth Token from twilio.com/console
    $sid = 'ACef166ed4f1f7ea3314209afb7257784a';
    $token = 'd54b553fda912abe5c829e52c4b18d20';
    $client = new Client($sid, $token);
    
    
    $phone=$_SESSION['phone'];
    $na=$_SESSION['name'];
    
    
    // Use the client to do fun stuff like send text messages!
    $client->messages->create(
        // the number you'd like to send the message to
        
        $phone,
    
        [
            // A Twilio phone number you purchased at twilio.com/console
            'from' => '(215) 883-8964',
            // the body of the text message you'd like to send
            'body' => '[Mitmine]=> Dear '.$na. ', Your OTP to change password is : ' .$pay
        ]
    );


*/
?>

<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Enter OTP</h3>
			<p align="center" style="color:red; font-size:11px; font-family:arial">***OTP has been sent to your mail or phone. ***</p>
		<form id="otp_p" method="post">
		


<div class="lform" style="text-align:center;" >

	<i class="fa fa-lock" id="fap" aria-hidden="true"></i>
<input type="text" name="otp" class="txt" placeholder="Enter OTP from your email" autocomplete="off" required></div>








<div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" id="reg_button" > <i class="fa fa-sign-in" id="uroo"> </i> Proceed</button><br> <br><br></div>

	<div  class="load_chat" style="width:100%"></div>

</div>
</form>

	</div>



</div>