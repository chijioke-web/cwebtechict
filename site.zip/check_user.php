<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';
$ref='email';
$ref_field= clean($_GET['phone']);
$ck=$obj->check_user($tb,$ref,$ref_field);
?>