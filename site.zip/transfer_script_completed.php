<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';
$tpin='pin';
$pin_f='pin';
$pin=clean($_POST['otp']);
$send_wallet='wallet';
$email_filed='email';
$email=$_SESSION['ema'];
$id='id';
$idd=$_SESSION['id'];
$amt=$_SESSION['amount'];
$used='used';
$not='used';
$log=$obj->transfer_complete($tb,$tpin,$pin_f,$pin,$id,$idd,$send_wallet,$email_filed,$email,$amt,$used,$not);




 
?>