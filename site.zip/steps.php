<div class="how_it_works">
<img src="pix/plot_wave_bg.png" class="wave">

<div class="abt_text"><span class="txp" >Explore four basic steps to start earning!</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption2" >How Squixfund works?</span></div>

<div class="step_control">
<div class="abt_step" ><div class="img_div_step"><img src="pix/w1.png" class="abt_images" ></div>
	<h3 >SIGN UP</h3>

	<span >Register a free account and start your first step to passive daily income.</span>

</div>


<div class="abt_step" ><div class="img_div_step"><img src="pix/w2.png" class="abt_images" ></div>
	<h3  >DEPOSIT FUND</h3>

	
<span >Fund your wallet by paying directly into the company's wallet address that will be provided by the system.</span>

</div>


<div class="abt_step" ><div class="img_div_step"><img src="pix/w3.png" class="abt_images" ></div>
	<h3  >START INVESTING</h3>

	
<span  >Choose a suitable plan from our well packaged 3 plans to get started. Percentage Profits offered depends on the plan selected. Your capital and profit are withdrawn when the duration for the investment is due.</span>

</div>

<div class="abt_step" ><div class="img_div_step"><img src="pix/w4.png" class="abt_images" ></div>
	<h3  >WITHDRAWAL </h3>


<span  >After a successful investment,your  profit and capital can be withdrawn when investment period is over. You can as well decide to reinvest. You can also withdraw your referral bonus at a minimum of $100.
</span>
</div>

</div>
</div>