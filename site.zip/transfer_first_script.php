<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';

$email=clean($_POST['email']);
$email_field='email';
$amount=clean($_POST['amt']);
$sess_email=$_SESSION['email'];
$id='id';
$idd=$_SESSION['id'];
$amount_field='wallet';
$date=date("d-m-Y");

$log=$obj->transfer_fund_first($tb,$email,$email_field,$amount,$amount_field,$id,$idd,$sess_email);

$field_data=array('id int(100) not null auto_increment primary key',
	'pin varchar(100)not null',
'used varchar(100)not null',
'datex varchar(100)not null',
);
$tbx='pin';
$crt=$obj->create_table($tbx,$field_data);



 
?>