<div class="about">
<div class="abt_text" ><span class="txp" style="color:#F60">ABOUT Squixfund</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption">The best way to passive income</span></div>

<div class="abt" ><div class="img_div"><img src="pix/about_icon_1.png" class="abt_images"></div>
	<h3>Interest</h3>

	By subscribing to our services, we guarantee you interest from your investment.

</div>


<div class="abt" ><div class="img_div"><img src="pix/about_icon_1c.png" class="abt_images"></div>
	<h3>Invite your friends</h3>

	
It is much more profitable to invest together. Why? Because by inviting friends via a referral link, you get a bonus that will definitely please you.

</div>


<div class="abt" ><div class="img_div"><img src="pix/about_icon_2.png" class="abt_images"></div>
	<h3>Investment problems free</h3>

	
Our platform is designed for regular payments, a wide multifunctional selection of existing packages and for passive interest .

</div>

<div class="abt" ><div class="img_div"><img src="pix/about_icon_2c.png" class="abt_images"></div>
	<h3>Security</h3>


Considering all nuances of working with cryptocurrency, we took care of reliable security and confidentiality for our clients.

</div>


<div class="abt" ><div class="img_div"><img src="pix/about_icon_3c.png" class="abt_images"></div>
	<h3>User friendliness</h3>

	

Having been in the crypto world for a long time, we managed to provide safe and most importantly Easy investment on dedicated servers.


</div>


<div class="abt" ><div class="img_div"><img src="pix/choose_icon_2.png" class="abt_images"></div>
	<h3>Regular payments</h3>

	

Through our service, withdrawal requests are processed and paid out daily to our users.
</div>


<div class="abt" ><div class="img_div"><img src="pix/choose_icon_5.png" class="abt_images"></div>
	<h3>Income stability</h3>

	

Your profit and capital is added to your wallet utomatically when the investment period is completed.
</div>


<div class="abt" ><div class="img_div"><img src="pix/choose_icon_1.png" class="abt_images"></div>
	<h3>Efficient and sustainable mining</h3>

	
Our services combine all the key aspects of efficient cryptocurrency mining

</div>
</div>