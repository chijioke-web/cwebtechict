<script type="text/javascript" src="js/java2.js"></script>


<br><br><br>
<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Start Crypto Mining (<font color="red">12% ROI in 6 Days</font>)</h3>
		<form id="mining" method="post">
		


<div class="lform" style="text-align:center;" >

	<i class="fa fa-money" id="fap" aria-hidden="true"></i>
<input type="number" name="amt" class="txt" placeholder="Enter Mining amount" autocomplete="off" required min="12000" max="1000000"></div>








<div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" id="reg_button" > <i class="fa fa-sign-in" id="uroo"> </i> Start Mining</button><br> <br><br></div>

	<div  class="load_chat" style="width:100%"></div>

</div>
</form>

	</div>



</div>

