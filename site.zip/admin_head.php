<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
require 'expired_session2.php';
?>
<div class="head_container">
	<table width="100%">
	<tr><td><div class="logo_section"><a href="?"><img src="pix/logo.png" class="logo_image"></a></div></td><td align="right" width="40%"> <div class="navigation_section" style="line-height: 10px"><span class="desktop"><?php $obj->header_user_info('member_tb',$_SESSION['namex'],'flags/'.$_SESSION['nation'].'.png');?></span> <span class="miniscreen"><i class="fa fa-navicon" id="navicon"></i></span></div></td></tr></table>

</div>

<div class="head_container2">
	<table width="100%">
	<tr><td><div class="logo_section"><a href="?"><img src="pix/logo.png" class="logo_image"></a></div></td><td align="right" width="40%"> <div class="navigation_section" style="line-height: 10px"><span class="desktop"><?php $obj->header_user_info('member_tb',$_SESSION['namex'],'flags/'.$_SESSION['nation'].'.png');?></span> <span class="miniscreen"><i class="fa fa-navicon" id="navicon2"></i></span></div></td></tr></table>

</div>

<div class="navi">
<?php require 'nav_add.php';?>

	</div>

	<div class="show_profile"><center><?php $obj->header_user_info('member_tb',$_SESSION['namex'],'flags/'.$_SESSION['nation'].'.png');?></center></div>