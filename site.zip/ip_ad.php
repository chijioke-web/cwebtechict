<?php 

$vis_ip = $_SERVER['REMOTE_ADDR']; 

  
// Display the IP address 




// PHP code to obtain country, city,  
// continent, etc using IP Address 

  

$ip = $vis_ip; 

  
// Use JSON encoded string and converts 
// it into a PHP variable 

$ipdat = @json_decode(file_get_contents( 

    "http://www.geoplugin.net/json.gp?ip=" . $ip)); 

   $contry=$ipdat->geoplugin_countryName;
   $region=$ipdat->geoplugin_region;


?> 
