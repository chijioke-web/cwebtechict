<?php
echo hash('sha256','BitralaxFx2022@#');

?>