<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='admin_tb';
$id='id';
$idd=$_SESSION['idx'];
$pass_field='password';

$pa=clean($_POST['password']);
$pass=hash('sha256',$pa);
$log=$obj->change_pass_function_ad($tb,$id,$idd,$pass_field,$pass);

?>