<?php 



header("location:dashboard?#u/o/?/page=contact_support");

?>