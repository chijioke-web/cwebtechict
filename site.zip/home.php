
<div class="container">


	<div class="left" data-aos="zoom-in" data-aos-duration="2000"><span class="all"><span class="logtex"data-aos="zoom-in" data-aos-duration="2000">BITRALAX</span data-aos="zoom-in" data-aos-duration="2000">FX</span><br>

		
		<br>
		<span class="left_txtx" data-aos="zoom-in" data-aos-duration="2000">
			BitralaxFx is a private online cryptocurrency mining & trading company that has been legally registered in Australia in 2018. <p>It is an association of a large number of professional Cryptocurrency Miners and Traders into one group in order to achieve a higher efficiency of bulk cryptocurrency.</p><p> In comparison with earlier stages of development, the company has significantly expanded its activities by mining cryptocurrency and trading several financial instruments.</p> Simultaneous mining of multiple digital currencies allows BitralaxFx to diversify risks by blocking the sagging rate of one of them with a successful mining operations performed through the mining rigs.<br>
		<a href="#u/o/?/page=register" class="index"><button type="button" class="reg_but" data-aos="zoom-in" data-aos-duration="2000"><i class="fa fa-sign-in" id="urzj"> </i> Invest Now</button></a></span>
	</div>

	<div class="right" data-aos="zoom-in" data-aos-duration="2000"><img src="pix/ba.png" class="idesign"></div>

</div>



<div class="attributes" data-aos="zoom-in" data-aos-duration="2000">

	<div class="attr"data-aos="zoom-in" data-aos-duration="2000"><img src="pix/a.png" class="att_imag"><br><span class="tyx" id="total_reg"></span><br><span class="tyxj">
Registered Users
</span></div>


	<div class="attr" data-aos="zoom-in" data-aos-duration="2000"><img src="pix/b.png" class="att_imag"><br><span class="tyx" id="tot_trad_public"></span><br><span class="tyxj">Total Investment
</span></div>
<div class="attr" data-aos="zoom-in" data-aos-duration="2000"><img src="pix/d.png" class="att_imag"><br><span class="tyx" id="mined_public"></span><br><span class="tyxj"> 
Active Investment</span></div>



	<div class="attr" data-aos="zoom-in" data-aos-duration="2000"><img src="pix/c.png" class="att_imag"><br><span class="tyx" id="with_public_tot"></span><br><span class="tyxj">All Withdrawals</span></div>



</div>




<br><br>

<div class="about">
<div class="abt_text" data-aos="zoom-in" data-aos-duration="2000"><span class="txp" style="color:#F60">ABOUT BitralaxFx</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption">The best way to passive income</span></div>

<div class="abt" data-aos="zoom-in" data-aos-duration="2000"><div class="img_div"><img src="pix/about_icon_1.png" class="abt_images"></div>
	<h3>Interest</h3>

	By subscribing to our services, we guarantee you interest from your investment.

</div>


<div class="abt" data-aos="zoom-in" data-aos-duration="2000"><div class="img_div"><img src="pix/about_icon_1c.png" class="abt_images"></div>
	<h3>Invite your friends</h3>

	
It is much more profitable to invest together. Why? Because by inviting friends via a referral link, you get a bonus that will definitely please you.

</div>


<div class="abt" data-aos="zoom-in" data-aos-duration="2000"><div class="img_div"><img src="pix/about_icon_2.png" class="abt_images"></div>
	<h3>Investment problems free</h3>

	
Our platform is designed for regular payments, a wide multifunctional selection of existing packages and for passive interest .

</div>

<div class="abt" data-aos="zoom-in" data-aos-duration="2000"><div class="img_div"><img src="pix/about_icon_2c.png" class="abt_images"></div>
	<h3>Security</h3>


Considering all nuances of working with cryptocurrency, we took care of reliable security and confidentiality for our clients.

</div>


<div class="abt" data-aos="zoom-in" data-aos-duration="2000"><div class="img_div"><img src="pix/about_icon_3c.png" class="abt_images"></div>
	<h3>User friendliness</h3>

	

Having been in the crypto world for a long time, we managed to provide safe and most importantly Easy investment on dedicated servers.


</div>


<div class="abt" data-aos="zoom-in" data-aos-duration="2000"><div class="img_div"><img src="pix/choose_icon_2.png" class="abt_images"></div>
	<h3>Regular payments</h3>

	

Through our service, withdrawal requests are processed and paid out daily to our users.
</div>


<div class="abt" data-aos="zoom-in" data-aos-duration="2000"><div class="img_div"><img src="pix/choose_icon_5.png" class="abt_images"></div>
	<h3>Income stability</h3>

	

Your  profit and capital is added to your wallet automatically when investment period is completed.
</div>


<div class="abt" data-aos="zoom-in" data-aos-duration="2000"><div class="img_div"><img src="pix/choose_icon_1.png" class="abt_images"></div>
	<h3>Efficient and sustainable mining</h3>

	
Our services combine all the key aspects of efficient cryptocurrency mining

</div>
</div>

<div class="plans">


<div class="abt_text"><span class="txp" data-aos="zoom-in" data-aos-duration="2000">Our Investment Plans</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption" data-aos="zoom-in" data-aos-duration="2000">Profit Withdrawable when due</span></div>

<div class="step_control">


<div class="plan1"data-aos="zoom-in" data-aos-duration="2000">
<div class="in1"><img src="pix/package_icon_1.png" class="start_image"><br><span class="caption" style="color:black">STARTER</span></div>
<div class="inner1"><span class="captionxx">2.5%</span></div>

	<ul>
		<li>2.5% Daily Profit</li>
		<li>6 days Duration</li>
		<li>Instant Profit withdrawal after 24hrs</li>
		<li>10% Referral Bonus</li>
		<li>Minimum Investment: 100.00 USD</li>
		<li>Maximum Investment: 19,999.00 USD</li>
	</ul>

	<center><a href="#u/o/?/page=register" class="index"><button  id="plan_button1" type="submit">Sign Up</button></a></center>
</div>

<div class="plan2" data-aos="zoom-in" data-aos-duration="2000">
<div class="in2"><img src="pix/package_icon_2.png" class="start_image"><br><span class="caption" style="color:black">BASIC</span></div>
<div class="inner2"><span class="captionxx">3%</span></div>

	<ul>
		<li>3%  daily Profit </li>
		<li>6 days duration</li>
		<li>Instant Profit withdrawal after 6 days</li>
		<li>10% Referral Bonus</li>
		<li>Minimum Investment: 20,000.00 USD</li>
		<li>Maximum Investment: 49,999.00 USD</li>
	</ul>

	<center><a href="#u/o/?/page=register" class="index"><button  id="plan_button2" type="submit">Sign Up</button></a></center>
</div>


<div class="plan3" data-aos="zoom-in" data-aos-duration="2000">
<div class="in3"><img src="pix/package_icon_3.png" class="start_image"><br><span class="caption" style="color:black">GOLD</span></div>
<div class="inner3"><span class="captionxx">3.5%</span></div>

	<ul>
		<li>3.5% daily Profit</li>
		<li>6 days Duration</li>
		<li>Instant Profit withdrawal after 6 days </li>
		<li>10% Referral Bonus</li>
		<li>Minimum Investment: 50,000 USD</li>
		<li>Maximum Investment: Unlimied USD</li>
	</ul>

	<center><a href="#u/o/?/page=register" class="index"><button  id="plan_button3" type="submit">Sign Up</button></a></center>
</div>


</div>
<div style="pointer-events: none;">

	<script src="https://widgets.coingecko.com/coingecko-coin-price-chart-widget.js"></script>
<coingecko-coin-price-chart-widget  coin-id="bitcoin" currency="usd" height="300" locale="en"></coingecko-coin-price-chart-widget>
<script src="https://widgets.coingecko.com/coingecko-coin-list-widget.js"></script>
<coingecko-coin-list-widget  coin-ids="bitcoin,ethereum,eos,ripple,litecoin" currency="usd" locale="en"></coingecko-coin-list-widget>

<script src="https://widgets.coingecko.com/coingecko-coin-heatmap-widget.js"></script>
<coingecko-coin-heatmap-widget  height="400" locale="en"></coingecko-coin-heatmap-widget>

<script src="https://widgets.coingecko.com/coingecko-coin-compare-chart-widget.js"></script>
<coingecko-coin-compare-chart-widget  coin-ids="bitcoin,ethereum,eos,ripple,litecoin" currency="usd" locale="en"></coingecko-coin-compare-chart-widget>
</div>
<img src="pix/plot_wave_bg.png" class="wave">
<div class="abt_text" data-aos="zoom-in" data-aos-duration="2000"><span class="txp">WHY YOU SHOULD INVEST WITH US?</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption">For Your Convenience And Safety</span></div>
<div style="width:100%; overflow: auto"><center><img src="pix/why.png"></center></div>


<div class="how_it_works">
<img src="pix/plot_wave_bg.png" class="wave">

<div class="abt_text"><span class="txp" data-aos="zoom-in" data-aos-duration="2000">Explore four basic steps to start earning!</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption2" data-aos="zoom-in" data-aos-duration="2000">How BitralaxFx works?</span></div>

<div class="step_control">
<div class="abt_step" data-aos="zoom-in" data-aos-duration="2000"><div class="img_div_step"><img src="pix/w1.png" class="abt_images" ></div>
	<h3 data-aos="zoom-in" data-aos-duration="2000">SIGN UP</h3>

	<span data-aos="zoom-in" data-aos-duration="2000">Register a free account and start your first step to passive daily income.</span>

</div>


<div class="abt_step" data-aos="zoom-in" data-aos-duration="2000"><div class="img_div_step"><img src="pix/w2.png" class="abt_images" ></div>
	<h3 data-aos="zoom-in" data-aos-duration="2000" >DEPOSIT FUND</h3>

	
<span data-aos="zoom-in" data-aos-duration="2000">Fund your wallet by paying directly into the company's wallet address that will be provided by the system.</span>

</div>


<div class="abt_step" data-aos="zoom-in" data-aos-duration="2000"><div class="img_div_step"><img src="pix/w3.png" class="abt_images" ></div>
	<h3  data-aos="zoom-in" data-aos-duration="2000">START INVESTING</h3>

	
<span data-aos="zoom-in" data-aos-duration="2000" >Choose a suitable plan from our well packaged 3 plans to get started. Percentage Profits offered depends on the plan selected. Your capital and profit are withdrawn when the duration for the investment is due.</span>

</div>

<div class="abt_step" data-aos="zoom-in" data-aos-duration="2000"><div class="img_div_step"><img src="pix/w4.png" class="abt_images" ></div>
	<h3  data-aos="zoom-in" data-aos-duration="2000">WITHDRAWAL </h3>


<span  data-aos="zoom-in" data-aos-duration="2000">After a successful investment,your  profit and capital can be withdrawn when investment period is over. You can as well decide to reinvest. You can also withdraw your referral bonus at a minimum of $100.
</span>
</div>

</div>
</div>


<?php 

@require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$ta='announcement_tb';
$msg='msg';
$empty='';
$obj->show_announcement_pub($ta,$msg,$empty);



?>

