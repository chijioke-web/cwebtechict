<?php
@session_start();
if(isset($_SESSION['link'])){
echo $_SESSION['link'];

//echo "obi is a boy";
}

?>