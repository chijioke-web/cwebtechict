<div class="copy">

	Copyright © <?php echo date("Y");?>, <span style="color:#990033">Squixfund</span>. All Right Reserved<br><br>
<a href="#u/o/?/page=terms" class="index"><span class="terms">Terms & Conditions</span></a> ||  <a href="#u/o/?/page=privacy" class="index"><span class="privacy">Privacy Policy</span></a>
</div>