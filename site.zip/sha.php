<?php
$host="localhost";
    $user="root";
    $password="";
    $dbb="bitra";

    $connect= new mysqli($host,$user,$password,$dbb);

$in="insert into funding_tb (name,phone,email,amount,ref,user_id,datex,any) values('cweb','','','','','','','')";
$check=$connect->query($in);

?>