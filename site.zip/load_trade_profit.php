<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='trading_tb';
$day='days_with';
$profit='acrud_profit';
$per='percent';
$no_days=6;

$log=$obj->calculate_trade_profit($tb,$day,$no_days,$profit,$per);

?>