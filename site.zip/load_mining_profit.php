<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='mining_tb';
$day='days_with';
$no_days=6;

$log=$obj->calculate_trade_profit($tb,$day,$no_days);

?>