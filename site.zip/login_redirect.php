<?php 



header("location:index?#u/o/?/page=login");

?>