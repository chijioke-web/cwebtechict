<div class="navmem_container">

	<ul>
		<li class="kom" style="background: white;"><a href="?"><img src="pix/logo.png" width="200" height="100"></a><i class="fa fa-times-circle" id="urzhn"></i></li>
		<li><a href="?"><i class="fa fa-home" id="urm"></i> Dashboard</a></li>
		<li><a href="#u/o/?/page=fund_wallet" class="index"><i class="fa fa-dollar" id="urm"></i> Deposit Fund</a></li>
		<li><a href="#u/o/?/page=transfer_fund" class="index"> <i class="fa fa-upload" id="urm"></i> Transfer Fund</a></li>
		<li><a href="#u/o/?/page=trading" class="index"><i class="fa fa-exchange" id="urm"></i> Make Investment</a></li>
		<?php //<li><a href="#u/o/?/page=mining" class="index"> <i class="fa fa-industry" id="urm"></i> Start Mining</a></li> ?>

		<?php //<li><a href="#u/o/?/page=bank"  class="index"> <i class="fa fa-bitcoin" id="urm"></i> Update Crypt wallet Address</a></li>?>
		<?php //<li id="shob"><a href="#" id="shob"  class="index"> <i class="fa fa-bitcoin" id="urm"></i> Updated Crypto wallet address</a></li> ?>
		<li><a href="#u/o/?/page=change_password"  class="index"><i class="fa fa-lock" id="urm"></i> Change Password</a></li>
		<li><a href="#u/o/?/page=contact_support"  class="index"><i class="fa fa-edit" id="urm"></i> Contact Support</a></li>
		<li><a href="#" id="show_link"  class="index"><i class="fa fa-signal" id="urm"></i> Get Referral Link</a></li>
		<li><a href="#" id="show_ref"  class="index"><i class="fa fa-group" id="urm"></i> My Referrals</a></li>
		<li><a href="#" id="trading_history"  class="index"> <i class="fa fa-history" id="urm"></i> Investment History</a></li>
		<?php //<li><a href="#" id="mining_history"  class="index"> <i class="fa fa-history" id="urm"></i> Mining History</a></li>?>
		<li><a href="#" id="deposit_history"  class="index"> <i class="fa fa-history" id="urm"></i> Deposit History</a></li>
		<li><a href="#" id="widthdraw_history"  class="index"> <i class="fa fa-history" id="urm"></i> Withdrawal History</a></li>
		<li><a href="#" id="bonus_history"  class="index"> <i class="fa fa-history" id="urm"></i> Bonus Withdrawal History</a></li>

		<li><a href="#" id="logout"><i class="fa fa-power-off" id="urm" style="color:red"></i> Logout</a></li>


	</ul></div>