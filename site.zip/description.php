<?php
echo "BitralaxFx  is a legal crypto currency management company for smart investors with definite financial goals
     We source our income from foreign exchange investments, simple management of funds and expertise in cryptocurrency trades..";
?>