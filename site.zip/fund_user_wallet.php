
<script type="text/javascript" src="js/java2.js"></script>

<br>
<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Fund User's Wallet</h3>
		


<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';



       $obj->fund_user_wallet('funding_tb','name','phone','ref','amount','id','user_id','any','pending','datex');

    


?><br> <br><br></div>

	

</div>


	</div>



</div>

