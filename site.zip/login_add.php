<script type="text/javascript" src="js/java2.js"></script>


<img src="pix/plot_wave_bg.png" class="wave">

<div class="abt_text"><span class="txp">Admin Account Login</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption2" style="color:white">100% Secure</span></div>
<div class="contact">

		


	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Account Login</h3>
		<form id="login_form_add" method="post">
		


<div class="lform" style="text-align:center;" >

	<i class="fa fa-envelope" id="fap" aria-hidden="true"></i>
<input type="email" name="email" class="txt" placeholder="Your email" autocomplete="off" required></div>

<div class="lform" style="text-align:center;" >

	<i class="fa fa-lock" id="fap" aria-hidden="true"></i>
<input type="password" name="password" class="txt" placeholder="Your password" autocomplete="off" required id="txt"></div>
<div class="showp">
<input type="checkbox" class="ckbox"><span id="ckbox">Show Password</span>
</div>




<div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" id="reg_button" > <i class="fa fa-sign-in" id="uroo"> </i> Login</button><br><br> <br><br></div>

	

</div>
</form>

	</div>



</div>
