<?php 


header("location:admin#u/o/?/page=announcement");

?>