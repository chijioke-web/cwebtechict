<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='withdraw_tb';
$id='id';
$idd=clean($_POST['id']);
$obj->delete_w($tb,$id,$idd);