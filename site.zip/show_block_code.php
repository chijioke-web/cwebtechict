
<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$sel="select * from member_tb where id='".$_SESSION['id']."' and show_w=''";
$sql=$conn->query($sel);
if($sql->num_rows>=1){?>

	<div id="show_block_main">


		<div id="div_block">
<h3 align="center" style="font-family: microsoft new tai lue"> Share this information on whatsapp status or facebook</h3> 
			I just made a withdrawal from Cryptojet  <br>
 


CRYPTO JET IS SECURE, TRUSTED AND EFFICIENT, WITH THE HELP OF CRYPTO MINING AND TRADING ON OUR SERVICE, WILL PROVIDE YOU THE OPPORTUNITY TO MULTIPLY YOUR INCOME WITH PASSIVE INTEREST<br>

Join me as we earn 10% daily  on cryptojet <br>

https://cryptojet.us/ref?ref=<?php echo $_SESSION['email'];?><br>

<a href="https://wa.me/?text=I %20just %20made %20a %20withdrawal %20from %20Cryptojet. %20CRYPTO %20JET %20IS %20SECURE,%20 TRUSTED %20AND %20EFFICIENT, %20WITH %20THE %20HELP %20OF %20CRYPTO %20MINING %20AND %20TRADING %20ON %20OUR %20SERVICE, %20WILL %20PROVIDE %20YOU %20THE %20OPPORTUNITY %20TO %20MULTIPLY %20YOUR %20INCOME %20WITH%20 PASSIVE%20 INTEREST %20Join %20me %20as %20we %20earn %2010% %20daily %20on %20cryptojet %20https://cryptojet.us/ref?ref=<?php echo $_SESSION['email'];?>" data-action="share/whatsapp/share" target="_blank"><button type="button" class="backw"><i class="fa fa-whatsapp" id="urkkkk"></i> Share on whatsapp Status</button></a><br>

<!-- Load Facebook SDK for JavaScript -->
<div id="fb-root"></div>
<script>(function(d, s, id) {
var js, fjs = d.getElementsByTagName(s)[0];
if (d.getElementById(id)) return;
js = d.createElement(s); js.id = id;
js.src = "https://connect.facebook.net/en_US/sdk.js#xfbml=1&version=v3.0";
fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<!-- Your share button code -->
<div class="fb-share-button" 
data-href="https://www.cryptojet.us/ref?ref=<?php echo $_SESSION['email'];?>" 
data-layout="button_count">
</div><br>
<font color="red">***Note: after sharing on your status, please screenshot and upload***.</font><br>
<button class="uploaderx" type="button">Upload screenshot</button><br>
<div class="sh_for" style="display: none;">
<form id="uploader">
	<input type="file" name="file" required><br><br>
	<button type="submit" class="upn">Upload now</button>
</form>
</div>
<div style="text-align:center"><div class="msg"></div>
</div></div>
<?php

}
?>

<script type="text/javascript">
	$(document).ready(function(){

		$(".uploaderx").click(function(){
$(this).hide(10);
    $(".sh_for").fadeIn(1000);
    
});



//delete announcement
$("#uploader").submit(function(e){
e.preventDefault();



  $.ajax({
          url: "upload_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".upn").html("uploading...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"1","cursor":"not-allowed"});
    $(".upn").attr("disabled",true);

        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('uploaded ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
    

             //setTimeout(function(){$(".main").load('otp.php')},1000);
             setTimeout('window.location.href="ana3";',1000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".upn").html('Upload now').css({"opacity":"1","cursor":"pointer"});

  $(".upn").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });
	});

</script>