


<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$account=clean($_POST['accno']);
$b_code=clean($_POST['bankx']);
$bankay=clean($_POST['bank2']);
$_SESSION['bank_name']=$bankay;
$_SESSION['accno']=$account;
function callAPI($method, $url){
   $curl = curl_init();
  
   curl_setopt($curl, CURLOPT_URL, $url);
   
   curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($curl, CURLOPT_HTTPAUTH, CURLAUTH_BASIC);
   // EXECUTE:
   $result = curl_exec($curl);
   if(!$result){die("Connection Failure");}
   curl_close($curl);
   return $result;
}

$get_data = callAPI('GET', 'https://mobileairtimeng.com/money-transfer/get-account?userid=07056128644&pass=7a3794926c77d82d5aff5c&accno='.$account.'&bankcode='.$b_code.'&jsn=json');
$response = json_decode($get_data,true);

$cc_na=$response["message"];
$status=$response["status"];

if($status=='success'){
  $_SESSION['acc_name']=$cc_na;
  echo 1;
}
else{
  echo "Cannot verify account number at this time. please check your account number and try again later";
}
  

?>

