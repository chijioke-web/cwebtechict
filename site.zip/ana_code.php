<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';
$id='id';
$idd=$_SESSION['id'];
$ana='ana';
$empty='';
$obj->close_announcement($tb,$id,$idd,$ana,$empty);