<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$field_data=array('id int(100) not null auto_increment primary key',
	'name varchar(100)not null',
'amount varchar(100)not null',
'percent varchar(100)not null',
'acrud_profit int(100)not null',
'dat_inv varchar(100)not null',
'date_rec varchar(100)not null',
'days_with int(100)not null',
'status varchar(100)not null',
'user_id int(100)not null',
'trad_id varchar(100)not null',
'any varchar(100)not null',
'plan varchar(100)not null'
);
$tb_trad='trading_tb';
$crt=$obj->create_table($tb_trad,$field_data);
$id='id';
$idd=$_SESSION['id'];
$amount=clean($_POST['amt']);
$wallet='wallet';
$name=$_SESSION['name'];
function getDays(){
	$planx=clean($_POST['plan']);
	$perx='';
	if($planx=='Starter'){
		$perx=0;
	}
	else if($planx=='Basic'){
		$perx=0;
	}
	else if($planx=='Gold'){
		$perx=0;
	}
	else if($planx=='Premium'){
		$perx=0;
	}
	return $perx;

}


function getRec(){
	$planx=clean($_POST['plan']);
	$perx='';
	if($planx=='Starter'){
		$perx=strtotime("+6 days");
	}
	else if($planx=='Basic'){
		$perx=strtotime("+6 days");
	}
	else if($planx=='Gold'){
		$perx=strtotime("+6 days");;
	}
	else if($planx=='Premium'){
		$perx=strtotime("+6 day");;
	}
	return $perx;

}
$dayrec=getRec();

$getDay=getDays();

$date_in=date("d-m-Y");
//$da=strtotime("+30 days");
$date_rec=date("d-m-Y",$dayrec);
$day_with=$getDay;
$status='active';
$tb='member_tb';
$plan=clean($_POST['plan']);

function getPercentage(){
	$amountx=clean($_POST['amt']);
	$planx=clean($_POST['plan']);
	$perx='';
	if($planx=='Starter'){
		$perx=(2.5/100)*$amountx;
	}
	else if($planx=='Basic'){
		$perx=(3/100)*$amountx;
	}
	else if($planx=='Gold'){
		$perx=(3.5/100)*$amountx;
	}
	else if($planx=='Premium'){
		$perx=(100/100)*$amountx;
	}
	return $perx;

}

$pak=getPercentage();
$per=$pak;
$profita=$amount;
function password(){
    $le=7;
    $cha='ABCDEFGHIJKLMNOPQRSTUVWXYZ01234567892345678901234567890';
    $mai="";
    for($i=0;$i<$le;$i++){
    @$mai.=$cha[mt_rand(0,strlen($cha))];
    }
    return $mai;
    }
    $pass=password();
    $dd='BITRA#';
    $pay=$dd.$pass;
    $any='';

$fields=array(
	'name',
	'amount',
	'percent',
	'acrud_profit',
	'dat_inv',
	'date_rec',
	'days_with',
	'status',
	'user_id',
	'trad_id',
	'any',
	'plan'
);

$values=array(
$name,
$amount,
$per,
$profita,
$date_in,
$date_rec,
$day_with,
$status,
$idd,
$pay,
$any,
$plan

);
$email='ref_id';
$ref=$_SESSION['ref'];
$paid='paid';
$refwallet='ref_wallet';


function getRefbonus(){
	$amountx=clean($_POST['amt']);
	$planx=clean($_POST['plan']);
	$perx='';
	if($planx=='Starter'){
		$perx=(10/100)*$amountx;
	}
	else if($planx=='Basic'){
		$perx=(10/100)*$amountx;
	}
	else if($planx=='Gold'){
		$perx=(10/100)*$amountx;
	}
	else if($planx=='Premium'){
		$perx=(10/100)*$amountx;
	}
	return $perx;

}
$bony=getRefbonus();

$per_ref=$bony;
$reg=$obj->trading($tb,$amount,$wallet,$id,$idd,$tb_trad,$fields,$values,$email,$ref,$paid,$refwallet,$per_ref);

?>