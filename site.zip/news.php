<br>
<div class="letter_news">
<div class="letter2">
	<br><br>
	<center><h2 style="color:white;">NO NEWS FOUND</h2></center>
<br><br><br>
</div></div><br><br>

<script type="text/javascript">
	

$(".ref_div").css("display","none");
$(".letter").css("display","none");
$(".link").css("display","none");

</script>