<div class="trans"><center><div id="google_translate_element" style="color:white; width:150px;" align="center"></div>
 
<script type="text/javascript">
  
function googleTranslateElementInit() {
  new google.translate.TranslateElement({pageLanguage: 'en'}, 'google_translate_element');
}

</script>

<script type="text/javascript" src="//translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script></center></div>

<!doctype html>
<html  lang="en">
<head>
<meta charset="uft-8">
<title><?php require('title.php');?></title>
<meta name="description" content="<?php require('description.php');?>">
<meta  name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=1.0,user-scalable=no">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="<?php require('keyword.php');?>">
<meta name="theme-color" content="brown">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
<script type="text/javascript" src="js/java.js"></script>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="shortcut icon" href="pix/logo.png" type="image/png">
<link rel="stylesheet" href="css/css.css" media="all" type="text/css">


<script src="//code.jivosite.com/widget/nlfdvEBZJX" async></script>



</head>
