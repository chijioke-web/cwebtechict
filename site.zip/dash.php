<div class="dash_content">

<div class="bod">
	<div class="img_div_mem">
		<img src="pix/about_icon_1.png" class="abt_images_mem">
		</div>
		<span class="h3text"><br>Wallet Ballance</span>
<h1 class="amt_txt"><?php $obj->wallet_amount('member_tb','id',$_SESSION['id'],'wallet');?>
<div id="btc_price"></div>
<?php 

$obj->fund_wallet_buttons('member_tb','id',$_SESSION['id'],'wallet');
?> </h1>

<input type="hidden" id="dash_wallet" value="<?php  $obj->wallet_amount_btc('member_tb','id',$_SESSION['id'],'wallet');?>">
	</div>


	<div class="bod">
	<div class="img_div_mem">
		<img src="pix/package_icon_2.png" class="abt_images_mem">
		</div>
		<span class="h3text"><br>Amount Withdrawn</span>

<h1 class="amt_txt"><?php $obj->wallet_amount('member_tb','id',$_SESSION['id'],'withdrawal');?>
	
	<div id="btc_pricew"></div>
</h1>
<input type="hidden" id="dash_walletw" value="<?php  $obj->wallet_amount_btc('member_tb','id',$_SESSION['id'],'withdrawal');?>">
	</div>


<div class="bod">
	<div class="img_div_mem">
		<img src="pix/about_icon_2.png" class="abt_images_mem"></div>
		<span class="h3text"><br>Referral Bonus</span>
<h1 class="amt_txt"><?php $obj->wallet_amount('member_tb','id',$_SESSION['id'],'ref_wallet');?>
<div id="btc_priceb"></div>
<?php
$obj->width_bonus_buttons('member_tb','id',$_SESSION['id'],'ref_wallet');
?></h1>
<input type="hidden" id="dash_walletb" value="<?php  $obj->wallet_amount_btc('member_tb','id',$_SESSION['id'],'ref_wallet');?>">
	</div>


	
</div>