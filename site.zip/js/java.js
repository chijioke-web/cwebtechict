
 
    
  
        var default_content="";


    
    checkURL();
    $('.index').click(function (e){

            checkURL(this.hash);

    });
    
    //filling in the default content
    default_content = $('.main').html();
    
    
    setInterval("checkURL()",250);
    


var lasturl="";

function checkURL(hash)
{
    if(!hash) hash=window.location.hash;
    
    if(hash != lasturl)
    {
        lasturl=hash;
        
        // FIX - if we've used the history buttons to return to the homepage,
        // fill the pageContent with the default_content
        
        if(hash=="")
        $('.main').html(default_content);
        
        else
        loadPage(hash);
    }
}


function loadPage(url)
{

    url=url.replace('#u/o/?/page=','');
    $('#loading').css('visibility','visible');
    $("#ba").css('display','block');

    $.ajax({
        type: "POST",
        url: "load_page.php",
        data: 'page='+url,
        dataType: "html",
        success: function(msg){
            
            if(parseInt(msg)!=0)
            {
                $('.main').html(msg);
                $('#loading').css('visibility','hidden');
                $("#ba").css('display','none');
                $(window).scrollTop(0);
              

            }
        }
        
    });

}                                          


function disableCtrlKeyCombination(e)
        {
                //list all CTRL + key combinations you want to disable
                var forbiddenKeys = new Array("s");
                var key;
                var isCtrl;

                if(window.event)
                {
                        key = window.event.keyCode;     //IE
                        if(window.event.ctrlKey)
                                isCtrl = true;
                        else
                                isCtrl = false;
                }
                else
                {
                        key = e.which;     //firefox
                        if(e.ctrlKey)
                                isCtrl = true;
                        else
                                isCtrl = false;
                }

                //if ctrl is pressed check if other key is in forbidenKeys array
                if(isCtrl)
                {
                    for (i = 0; i < forbiddenKeys.length; i++)
                        {
                                //case-insensitive comparation
                            if (forbiddenKeys[i].toLowerCase() == String.fromCharCode(key).toLowerCase())
                                {
//                                    alert("Key combination CTRL + "
//                                                + String.fromCharCode(key)
//                                                + " has been disabled.");                                   
                                        return false;
                                }
                        }
                }
                return true;
        }

       
$(document).ready(function(){
    //index page

        $("nav ul .index").click(function(){

               $(".navi").css({"width":"0%","transition":"2s"});

$(".navi").css({"margin-left":"-100%","transition":"2s"});


        });
//for members navigation

         $(".navmem_container ul .index").click(function(){

               $(".navi").css({"width":"0%","transition":"2s"});

$(".navi").css({"margin-left":"-100%","transition":"2s"});


        });

        
        //$(".main").load("home.php");

 /* window.oncontextmenu=function(){
    $(".msgl").fadeIn(2000);
   $(".msgl").html('Right clicking not allowed');
   $(".msgl").css({"width":"300px","margin-top":"10%","margin":"0,auto","font-size":"18px","font-family":"arial","z-index":"60000","text-align":"center"});
$(".msgl").css({"background-color":"rgba(0,0,0,0.9)","padding":"30px","position":"fixed","color":"white","border-radius":"20px","right":"0px","bottom":"0px"});
   setTimeout(function(){$(".msgl").fadeOut(2000)},3000);
return false;
}
*/
 


  $(window).scroll(function(){
if($(window).scrollTop()>100){

  $(".head_container2").fadeIn(1000);
}
else{
  $(".head_container2").fadeOut("slow");
}
                }) ;


$("#navicon").click(function(){
$(".navmem_container").css({"width":"100%","transition":"1s"});
$(".navi").css({"width":"90%","transition":"1s"});
$(".navi nav ul li").css("display","block");
$(".navi .navmem_container ul li").css("display","block");
$(".navi").css({"margin-left":"0%","transition":"1s"});

});


$("#navicon2").click(function(){

$(".navmem_container").css({"width":"100%","transition":"1s"});
$(".navi").css({"width":"90%","transition":"1s"});
$(".navi nav ul li").css("display","block");
$(".navi .navmem_container ul li").css("display","block");

$(".navi").css({"margin-left":"0%","transition":"1s"});

});
// for index
$("nav #urzhn").click(function(){
$(".navi").css({"width":"0%","transition":"2s"});

$(".navi").css({"margin-left":"-100%","transition":"2s"});

$("#navicon").show(10);
$("#navicon2").show(10);
});

//for members

$(".navmem_container #urzhn").click(function(){
$(".navi").css({"width":"0%","transition":"2s"});

$(".navi").css({"margin-left":"-100%","transition":"2s"});

$("#navicon").show(10);
$("#navicon2").show(10);
});

//setInterval(function(){$("#load_trad_min").load("show_progress.php")},10000);

$(".navmem_container #shob").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('show_bank_details.php')},100);

});


$(".navmem_container #show_ref").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('show_ref.php')},100);

});

$(".navmem_container #trading_history").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('trading_history.php')},100);

});

$(".navmem_container #mining_history").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('mining_history.php')},100);

});

$(".navmem_container #deposit_history").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('deposit_history.php')},100);

});
$(".navmem_container #widthdraw_history").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('widthdraw_history.php')},100);

});
$(".navmem_container #bonus_history").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('bonus_history.php')},100);

});

$(".navmem_container #logout").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout('window.location.href="logout";',100);

});

$(".navmem_container #show_link").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('ref_link.php')},100);

});

$(".navmem_container #fund_user_ad").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('fund_user_wallet.php')},100);

});
$(".navmem_container #pay_user_ad").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('pay_withdrawal.php')},100);

});

$(".navmem_container #pay_user_bonus_ad").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('pay_withdrawal_bonus.php')},100);

});

$(".navmem_container #view_msgx").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('view_messages.php')},100);

});

$(".navmem_container #trading_history_ad").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('trading_history_ad.php')},100);

});

$(".navmem_container #mining_history_ad").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('mining_history_ad.php')},100);

});
$(".navmem_container #deposit_history_ad").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('deposit_history_ad.php')},100);

});

$(".navmem_container #widthdraw_history_ad").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('widthdraw_history_ad.php')},100);

});

$(".navmem_container #bonus_history_ad").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout(function(){$("#ba").show(1).hide(10);$(".main").load('bonus_history_ad.php')},100);

});

$(".navmem_container #logout_ad").click(function(){
    $("#ba").show(1).css("z-index","200000");
setTimeout('window.location.href="logout3";',100);

});
//news_letter
$("#newsletter").submit(function(e){
e.preventDefault();

  $.ajax({
          url: "news_letter_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Subscribing...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Our news letter subscription was successful ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             $(".txt").val('');
             $(".reg_but2").html('Send Message').css({"opacity":"1","cursor":"pointer"});
              $(".reg_but2").attr("disabled",false);
              setTimeout(function(){$(".msg").fadeOut(2000)},3000);
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Send Message').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });

setInterval(function(){$("#tot_trad_public").load("total_trade_public.php")},1000);
setInterval(function(){$("#mined_public").load("total_mine_public.php")},1000);
setInterval(function(){$("#with_public_tot").load("total_with_public.php")},1000);
setInterval(function(){$("#total_reg").load("total_reg.php")},1000);




    function getBTCPrice(){
      $.getJSON("https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD", function(json) {
    $("#btc_price").html(parseFloat($("#dash_wallet").val()/json.USD).toFixed(5)+' BTC');
     $(".txm").val(json.USD);
    //access your JSON file through the variable "json"
});
  }
  function getBTCPricew(){
      $.getJSON("https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD", function(json) {
    $("#btc_pricew").html(parseFloat($("#dash_walletw").val()/json.USD).toFixed(5)+' BTC');
     $(".txm").val(json.USD);
    //access your JSON file through the variable "json"
});
  }
  function getBTCPriceb(){
      $.getJSON("https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD", function(json) {
    $("#btc_priceb").html(parseFloat($("#dash_walletb").val()/json.USD).toFixed(5)+' BTC');
     $(".txm").val(json.USD);
    //access your JSON file through the variable "json"
});
  }

  function getBTCPricepay(){
    var tete=$('#price_hold').val();
      $.getJSON("https://min-api.cryptocompare.com/data/price?fsym="+tete+"&tsyms=USD", function(json) {
    $("#dv_c").html(parseFloat($("#amta").val()/json.USD).toFixed(5)+ ' '+tete);
     $(".txm").val(json.USD);
    //access your JSON file through the variable "json"
});
  }


  function getBTCPricebc(){
      $.getJSON("https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD", function(json) {
    $("#xx_withdraw").html(parseFloat($("#lox").html()/json.USD).toFixed(5)+' BTC');
     $(".txm").val(json.USD);
    //access your JSON file through the variable "json"
});
  }
  function getBTCPricebc_bonus(){
      $.getJSON("https://min-api.cryptocompare.com/data/price?fsym=BTC&tsyms=USD", function(json) {
    $("#xx_withdrawb").html(parseFloat($("#loxb").html()/json.USD).toFixed(5)+' BTC');
     $(".txm").val(json.USD);
    //access your JSON file through the variable "json"
});
  }
setInterval(function(){getBTCPrice(),getBTCPricew(),getBTCPriceb(),getBTCPricepay(),getBTCPricebc(),getBTCPricebc_bonus()},1000);


//close announcement
$("#close_ana").submit(function(e){
e.preventDefault();

  $.ajax({
          url: "ana_code.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".back").html("please wait...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".back").attr("disabled",true);
    
        },
      success: function(data)
        {
            if(data==1){
             $(".show_ana").hide(2000);
             setTimeout('window.location.href="dashboard";',1000);
            }
            else{ 
              
        
  $(".back").html('Close').css({"opacity":"1","cursor":"pointer"});
  $(".back").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });
$("#bakxx").click(function(){

  $(".show_ana").hide(2000);
})
//last
});

function show_diag(){
    var a=confirm("Do you wish to continue");
    if(a==true){
        alert("successful");

    }
    else{

    }
    return a;
}

function calculatex(){

    var amount=document.cal.plan.value;
    switch(amount){

        case"Starter": 
        document.cal.result.value='$30';
        break;
        case"Basic": 
        document.cal.result.value='$150';
        break;
        case"Standard": 
        document.cal.result.value='$300';
        break;
        case"Premium": 
        document.cal.result.value='$1,500';
        break;
        case"Investor": 
        document.cal.result.value='$6,000';
        break;
        case"Pro-Investor": 
        document.cal.result.value='$30,000';
        break;
        default:
        document.cal.result.value='0';
    }
}

function wallet_addx(){
    var coin=document.coin_fund.coin.value;

    switch(coin){

        case"BITCOIN":
        document.coin_fund.wallet_add.value='bc1qtwwst7fr8tn582f5e4hy3gd8dj57ys42302ay2';
        document.coin_fund.network.value='bitcoin';
        break;
        case"BNB":
         document.coin_fund.wallet_add.value='bnb1cutsw8f0rjv97gjwls5fw40av77qymmq6jz9ma';
        document.coin_fund.network.value='Bep2';
        break;
        case"DOGECOIN":
         document.coin_fund.wallet_add.value='DCDWYKTrBAZZhiSxN6pSFZaqwE6xzc5HZ7';
        document.coin_fund.network.value='dogecoin';
        break;
        case"USDT":
         document.coin_fund.wallet_add.value='TYXaU8xiwMkvRymZBcimTvig7f1baoNaQL';
        document.coin_fund.network.value='TRC20';
        break;
        case"TRON":
         document.coin_fund.wallet_add.value='TYXaU8xiwMkvRymZBcimTvig7f1baoNaQL';
        document.coin_fund.network.value='Tron(TRC20)';
        break;
        case"ETH":
         document.coin_fund.wallet_add.value='0x2c511d42C54382bE5351576a00bAD2f94337386F';
        document.coin_fund.network.value='ERC20';
        break;
        default:
        document.coin_fund.wallet_add.value='';
        document.coin_fund.network.value='';
    }
}

function invest_nwx(){
    var plan=document.tradingx.plan.value;
    switch(plan){

         case"Starter":
        document.tradingx.amt.value=100;
        document.tradingx.amt.min='100';
        document.tradingx.amt.max='19999';
        document.getElementById('show_pert').innerHTML='(<font color="red">2.5% ROI in 6 days</font>)';
        break;
        case"Basic":
        document.tradingx.amt.value=20000;
        document.tradingx.amt.min='20000';
        document.tradingx.amt.max='49999';
         document.getElementById('show_pert').innerHTML='(<font color="red">3% ROI in 6 days</font>)';
        break;
        case"Gold":
        document.tradingx.amt.value=50000;
        document.tradingx.amt.min='50000';
        document.tradingx.amt.max='50000000000000000000000000000000000000000000000000000000';
        document.getElementById('show_pert').innerHTML='(<font color="red">3.5% ROI in 6 days</font>)';
        break;
        case"Premium":
        document.tradingx.amt.value=5000;
        document.tradingx.amt.min='5000';
        document.tradingx.amt.max='9000000000000000000000000000000000000000';
         document.getElementById('show_pert').innerHTML='(<font color="red">100% ROI in 6 days</font>)';
        break;
        
        default:
        document.tradingx.amt.value=0;
    }
}