<?php 
session_start();
?>
<script type="text/javascript" src="js/java2.js"></script>


<br><br><br>
<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue">Referral Link</h3>
		<form id="otp" method="post">
		


<div class="lform" style="text-align:center; background: transparent;box-shadow: 0px 0px 1px 1px brown;color:black;" >

	
<input type="text" name="otp" class="txt" placeholder="ref link" autocomplete="off" required readonly value="https://bitralaxfx.com/ref?ref=<?php echo $_SESSION['ref_id'];?>" style="color:black" id="cop"> <i class="fa fa-copy" id="coy"  title="copy link"></i></div><center><span style="color:red">Click on the icon at the right side of the box to copy link</span></center>

<script type="text/javascript">
    
  $("#coy").click(function(){
var copy=document.getElementById('cop');
copy.select();
document.execCommand('copy');
$(".msgl").fadeIn(1000);
   $(".msgl").html('Referral Link Copied');
   $(".msgl").css({"width":"300px","margin-top":"10%","margin":"0,auto","font-size":"18px","font-family":"arial","z-index":"60000","text-align":"center"});
$(".msgl").css({"background-color":"rgba(0,0,0,0.9)","padding":"30px","position":"fixed","color":"white","border-radius":"20px","right":"0px","bottom":"0px"});
   setTimeout(function(){$(".msgl").fadeOut(2000)},3000);
});

</script>







</div>
</form>

	</div>



</div>

