<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';

$pass=clean($_POST['password']);

$log=$obj->change_password($pass);

?>