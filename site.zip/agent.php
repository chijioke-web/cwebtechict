
<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='funding_tb';
$network='network';
$id='user_id';
$idd=$_SESSION['id'];
$coin='coin';
$amount='amount';
$addr='wallet_add';
$status='any';
$active='pending';
$idx='id';


$obj->show_wallet_pay($tb,$network,$id,$idd,$coin,$amount,$addr,$status,$active,$idx);

?>