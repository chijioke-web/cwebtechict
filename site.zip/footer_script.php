
<div class="msgl"></div>


<h2 align="center">INVESTORS TESTIMONIALS</h2>
 <br><br><br><br><br><br><br><br><br><br><br><br><br><br>
	<div class="slider">
     
<?php require 'slider.php';?>

    </div>
<div class="footer">
  

<?php require 'ref_home.php';?>


</div>
<?php require 'footer.php';?>
<?php require 'news_letter.php';?>


<img src="pix/plot_wave_bg.png" class="wave">
<?php require 'copyright.php';?>


</body>
</html>