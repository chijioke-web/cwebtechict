
<div class="footerx">

<div class="link" data-aos="zoom-in" data-aos-duration="2000">
	<h4 data-aos="zoom-in" data-aos-duration="2000">Contact Us</h4>
	<ul>
	<li><i class="fa fa-map-marker" id="fa"></i> 1 & 2/110 Chambers Road Altona North VIC 3025 Australia</li>
                     <li><a href="mailto:support@BitralaxFx.com"><i class="fa fa-envelope" id="fa"></i> support@BitralaxFx.com</a></li>
                      


	</ul>
	
</div>


<div class="link" data-aos="zoom-in" data-aos-duration="2000">
	<h4 data-aos="zoom-in" data-aos-duration="2000">Quick Links</h4>
	<ul>
	<li><a href="#u/o/?/page=about" class="index">About Us</a></li>
    <li><a href="#u/o/?/page=contact" class="index">Contact Us</a></li>
    <li><a href="#u/o/?/page=steps" class="index">How it works</a></li>
    <li><a href="#u/o/?/page=plans" class="index">Plans</a></li>
    <li><a href="#u/o/?/page=register" class="index">Sign Up</a></li>
    <li><a href="#u/o/?/page=login" class="index">Login</a></li>
                      


	</ul>
	
</div>


<div class="link" data-aos="zoom-in" data-aos-duration="2000">
	<h4 data-aos="zoom-in" data-aos-duration="2000">Social</h4>
	<ul>
	<li><a href="#" target="_blank"><i class="fa fa-facebook" id="fa"></i> Facebook</a></li>
	
	<li><a href="https://t.me/+WNSrbvWn8rA1NGU0z" target="_blank"><i class="fa fa-telegram" id="fa"></i> Telegram</a></li>
                    


	</ul>
	
</div>

<div class="link" data-aos="zoom-in" data-aos-duration="2000">
	<img src="pix/cert.png" width="200">
</div>


</div>

