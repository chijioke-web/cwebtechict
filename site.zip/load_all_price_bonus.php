<?php 

require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$sel="select * from member_tb where id='".$_SESSION['id']."'";
$sq=$conn->query($sel);
$row=$sq->fetch_assoc();
echo $row['ref_wallet'];

?>