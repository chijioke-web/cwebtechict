<?php
/*require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
*/
$selc="select * from trading_tb where user_id='".$_SESSION['id']."' and status='active'";
$sx=$conn->query($selc);
if($sx->num_rows>=1){


		$obj->show_current_trad('trading_tb','user_id',$_SESSION['id'],'status','active','trad_id','amount','percent','acrud_profit','profit','days_with','dat_inv','date_rec');

	}

/*$selcm="select * from mining_tb where user_id='".$_SESSION['id']."' and status='active'";
$sxm=$conn->query($selcm);
if($sxm->num_rows>=1){

$obj->show_current_min('mining_tb','user_id',$_SESSION['id'],'status','active','trad_id','amount','percent','acrud_profit','profit','days_with','dat_inv','date_rec');
	}	
	*/
?>