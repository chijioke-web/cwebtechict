<script>
    
    window.oncontextmenu=function(){
    $(".msgl").fadeIn(2000);
   $(".msgl").html('Right clicking not allowed');
   $(".msgl").css({"width":"300px","margin-top":"10%","margin":"0,auto","font-size":"18px","font-family":"arial","z-index":"60000","text-align":"center"});
$(".msgl").css({"background-color":"rgba(0,0,0,0.9)","padding":"30px","position":"fixed","color":"white","border-radius":"20px","right":"0px","bottom":"0px"});
   setTimeout(function(){$(".msgl").fadeOut(2000)},3000);
return false;
}

</script>

<div style="background:white; width: 100%; border-bottom: 1px solid lightgrey; pointer-events: none;"><script src="https://widgets.coingecko.com/coingecko-coin-price-marquee-widget.js"></script>
<coingecko-coin-price-marquee-widget  coin-ids="bitcoin,ethereum,eos,ripple,litecoin" currency="usd" background-color="#ffffff" locale="en"></coingecko-coin-price-marquee-widget></div>
<div class="head_container">
	<table width="100%">
	<tr><td><div class="logo_section"><a href="?"><img src="pix/logo.png" class="logo_image"></a></div></td><td align="right" width="70%"> <div class="navigation_section"><span class="desktop"><?php require 'navigation.php';?></span> <span class="miniscreen"><i class="fa fa-navicon" id="navicon"></i></span></div></td></tr></table>

</div>

<div class="head_container2">
	<table width="100%">
	<tr><td><div class="logo_section"><a href="?"><img src="pix/logo.png" class="logo_image"></a></div></td><td align="right" width="70%"> <div class="navigation_section"><span class="desktop"><?php require 'navigation.php';?></span> <span class="miniscreen"><i class="fa fa-navicon" id="navicon2"></i></span></div></td></tr></table>

</div>

<div class="navi">
<?php require 'navigation.php';?>

	</div>
	