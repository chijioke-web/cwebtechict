<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$field_data=array('id int(100) not null auto_increment primary key',
	'name varchar(100)not null',
'amount varchar(100)not null',
'percent varchar(100)not null',
'acrud_profit int(100)not null',
'profit int(100)not null',
'total_profit int(100)not null',
'dat_inv varchar(100)not null',
'date_rec varchar(100)not null',
'days_with int(100)not null',
'status varchar(100)not null',
'user_id int(100)not null',
'trad_id varchar(100)not null',
'any varchar(100)not null'
);
$tb_trad='mining_tb';
$crt=$obj->create_table($tb_trad,$field_data);
$id='id';
$idd=$_SESSION['id'];
$amount=clean($_POST['amt']);
$wallet='wallet';
$name=$_SESSION['name'];
$per=(2/100)*$amount;
$per_total=(12/100)*$amount;
$per_total_final=$per_total+$amount;
$date_in=date("d-m-Y");
$da=strtotime("+6 days");
$date_rec=date("d-m-Y",$da);
$day_with='0';
$status='active';
$tb='member_tb';

function password(){
    $le=5;
    $cha='ABCDEFGHIJKLMNOPQRSTUVWXYZ01234567892345678901234567890';
    $mai="";
    for($i=0;$i<$le;$i++){
    @$mai.=$cha[mt_rand(0,strlen($cha))];
    }
    return $mai;
    }
    $pass=password();
    $dd='BIT#';
    $pay=$dd.$pass;
    $any='';

$fields=array(
	'name',
	'amount',
	'percent',
	'acrud_profit',
	'profit',
	'total_profit',
	'dat_inv',
	'date_rec',
	'days_with',
	'status',
	'user_id',
	'trad_id',
	'any'



);

$values=array(
$name,
$amount,
$per,
$day_with,
$amount,
$per_total_final,
$date_in,
$date_rec,
$day_with,
$status,
$idd,
$pay,
$any

);

$reg=$obj->mining($tb,$amount,$wallet,$id,$idd,$tb_trad,$fields,$values);

?>