<script type="text/javascript" src="js/java2.js"></script>


<script type="text/javascript">
	$(document).ready(function(){
	$(".ref_div").css("display","none");
});
	
</script>

<img src="pix/plot_wave_bg.png" class="wave">

<div class="abt_text"><span class="txp">Terms and Conditions</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption2" style="color:white">BitralaxFx</span></div>
<div class="contact">

	<div class="terms">	


	
<h3 align="center" style="font-family: microsoft new tai lue">Terms and Conditions</h3>
	<h3>Dear User,</h3>

<p>Welcome to BitralaxFx! This is a User Agreement between you (also referred to herein as “Client,” “User,” or customer) and BitralaxFx ("BitralaxFx"). This User Agreement ("Agreement") governs your use of the services provided by BitralaxFx described below ("BitralaxFx Services" or "Services"). By signing up to use an account through BitralaxFx.us, APIs, or the BitralaxFx mobile application (collectively the "BitralaxFx Site"), you agree that you have read, understand, and accept all of the terms and conditions contained in this Agreement including Section 10.3. "Arbitration; Waiver of Class Action", as well as our Privacy Policy, Cookie Policy, and E-Sign Consent Policy.</p>

<p>Before registering a user’s account with BitralaxFx , or engaging yourself with any services provided by/through BitralaxFx.us or any associated websites, APIs, mobile applications (collectively the “Platform”), please make sure you have read and understood each and every term and condition contained in this Agreement. We may, in our sole discretion, refuse to open a BitralaxFx Account, or limit the number of BitralaxFx Accounts that you may hold or suspend or terminate any BitralaxFx Account or the trading of specific Digital Currency in your account.</p>

<p>By registering a BitralaxFx account, you represent that you are over 18 years old, with physical and mental capacity to enter into this Agreement and you have read, understand, and accept all terms and conditions contained in this User Agreement, Privacy Policy,any Amendments, Appendices, or other covenants that may be modified from time to time and be posted on BitralaxFx , or be delivered to you through mails, emails, SMS, or other methods that are employed by BitralaxFx .</p>
</div>

</div>
