<script type="text/javascript" src="js/java2.js"></script>


<script type="text/javascript">
	$(document).ready(function(){
	$(".ref_div").css("display","none");
});
	
</script>

<script type="text/javascript">
<!-- 
//Browser Support Code
function ajaxFunctiona(){
	var ajaxRequest;  // The variable that makes Ajax possible!
	
	try{
		// Opera 8.0+, Firefox, Safari
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		// Internet Explorer Browsers
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				// Something went wrong
				alert("Your browser broke!");
				return false;
			}
		}
	}
	// Create a function that will receive data sent from the server
	ajaxRequest.onreadystatechange = function(){
		if(ajaxRequest.readyState == 4){
			var ajaxDisplay = document.getElementById('ajaxDiv');
			ajaxDisplay.innerHTML = ajaxRequest.responseText;
			
		}
	}
	var phone = document.getElementById('ref').value;
	
	var queryString = "?phone="+phone;
	
	ajaxRequest.open("GET", "check_user.php" + queryString,true);
	ajaxRequest.send(null); 
	
}

//-->

</script>

<script type="text/javascript">
<!-- 
//Browser Support Code
function ajaxFunctionap(){
	var ajaxRequest;  // The variable that makes Ajax possible!
	
	try{
		// Opera 8.0+, Firefox, Safari
		ajaxRequest = new XMLHttpRequest();
	} catch (e){
		// Internet Explorer Browsers
		try{
			ajaxRequest = new ActiveXObject("Msxml2.XMLHTTP");
		} catch (e) {
			try{
				ajaxRequest = new ActiveXObject("Microsoft.XMLHTTP");
			} catch (e){
				// Something went wrong
				alert("Your browser broke!");
				return false;
			}
		}
	}
	// Create a function that will receive data sent from the server
	ajaxRequest.onreadystatechange = function(){
		if(ajaxRequest.readyState == 4){
			var ajaxDisplay = document.getElementById('ajaxDiv2');
			ajaxDisplay.innerHTML = ajaxRequest.responseText;
			
		}
	}
	var email = document.getElementById('txt3').value;
	
	var queryString = "?email="+email;
	
	ajaxRequest.open("GET", "check_email.php" + queryString,true);
	ajaxRequest.send(null); 
	
}

//-->

</script>
<img src="pix/plot_wave_bg.png" class="wave">

<div class="abt_text"><span class="txp">Password Reset</span><br><br><img src="pix/title_tag_orange.png" class="abt_exim"><br><span class="caption2" style="color:white">Always Secure</span></div>
<div class="contact">

		


	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue">Create New Password</h3>
		<div class="valx"></div>
		<form id="reg_form_reset" method="post">
		
<div class="lform" style="text-align:center;" >

	<i class="fa fa-lock" id="fap" aria-hidden="true"></i>
<input type="password" name="password" class="txt" placeholder="Your password" autocomplete="off" required id="txt"></div>
<div class="showp">
<input type="checkbox" class="ckbox"><span id="ckbox">Show Password</span>
</div>
<div class="lform" style="text-align:center;" >

	<i class="fa fa-lock" id="fap" aria-hidden="true"></i>
<input type="password" name="pass" class="txt" placeholder="confirm password" autocomplete="off" required id="txt2"></div>
<div class="showp2"></div>



<div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" id="reg_button" >Reset</button><br> <br><br></div>

	

</div>
</form>

	</div>



</div>
