<script type="text/javascript" src="js/java2.js"></script>


<br><br><br>
<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Verify Account Number</h3>
		<form id="verify" method="post" name="frm">
		


<div class="lform" style="text-align:center;" >

	<i class="fa fa-credit-card" id="fap" aria-hidden="true"></i>
<input type="number" name="accno" class="txt" placeholder="Enter account number" autocomplete="off" required maxlength="10" ></div>





<div class="lform" style="text-align:center;" >

	<i class="fa fa-bank" id="fap" aria-hidden="true" ></i>
<select  name="bankx" id="txyb" required class="txt" style="color:brown" onchange="shoxw();">
<option value="">Select bank</option>
<option value="044">ACCESS BANK NIGERIA</option>
<option value="323">ACCESS MOBILE</option>
<option value="014">AFRIBANK NIGERIA PLC</option>
<option value="401">ASO SAVINGS AND LOANS</option>
<option value="063">ACCESS BANK PLC (DIAMOND)</option>
<option value="307">ECOBANK MOBILE</option>
<option value="050">ECOBANK NIGERIA LIMITED</option>
<option value="084">ENTERPRISE BANK LIMITED</option>
<option value="309">FBN MOBILE</option>
<option value="070">FIDELITY BANK PLC</option>
<option value="011">FIRST BANK PLC</option>
<option value="214">FCMB</option>
<option value="315">GTBANK MOBILE MONEY</option>
<option value="058">GTBANK PLC</option>
<option value="030">HERITAGE BANK</option>
<option value="082">KEYSTONE BANK PLC</option>
<option value="999129">KUDA BANK</option>
<option value="311">PARKWAY</option>
<option value="305">PAYCOM</option>
<option value="076">POLARIS BANK PLC</option>
<option value="221">STANBIC IBTC BANK PLC</option>
<option value="304">STANBIC MOBILE</option>
<option value="068">STANDARD CHARTERED BANK NIGERIA LIMITED</option>
<option value="232">STERLING BANK PLC</option>
<option value="032">UNION BANK OF NIGERIA PLC</option>
<option value="033">UNITED BANK FOR AFRICA PLC</option>
<option value="215">UNITY BANK PLC</option>
<option value="035">WEMA BANK PLC</option>
<option value="057">ZENITH BANK PLC</option>
<option value="322">ZENITH MOBILE</option>
<option value="559">CORONATION MERCHANT BANK</option>
<option value="101">PROVIDUS BANK</option>
<option value="526">PARRALEX BANK</option>
<option value="301">JAIZ BANK</option>
</select><br><input type="hidden" name="bank2" placeholder="bank"></div>




<div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" id="reg_button" > <i class="fa fa-sign-in" id="uroo"> </i> Verify Account</button><br> <br><br></div>

	<div  class="load_chat" style="width:100%"></div>

</div>
</form>

	</div>



</div>

<script type="text/javascript">
	function shoxw(){
		ba=document.frm.bankx.value;
		switch(ba){
			case '044':
		document.frm.bank2.value="ACCESS BANK NIGERIA";
		break;

		case '323':
		document.frm.bank2.value="ACCESS MOBILE";
		break;
		case '014':
		document.frm.bank2.value="AFRIBANK NIGERIA PLC";
		break;
		case '401':
		document.frm.bank2.value="ASO SAVINGS AND LOANS";
		break;
		case '063':
		document.frm.bank2.value="ACCESS BANK PLC (DIAMOND)";
		break;
		case '307':
		document.frm.bank2.value="ECOBANK MOBILE";
		break;
		case '050':
		document.frm.bank2.value="ECOBANK NIGERIA LIMITED";
		break;
		case '084':
		document.frm.bank2.value="ENTERPRISE BANK LIMITED";
		break;
		case '309':
		document.frm.bank2.value="FBN MOBILE";
		break;
		case '070':
		document.frm.bank2.value="FIDELITY BANK PLC";
		break;
		case '011':
		document.frm.bank2.value="FIRST BANK PLC";
		break;
		case '214':
		document.frm.bank2.value="FCMB";
		break;
		case '315':
		document.frm.bank2.value="GTBANK MOBILE MONEY";
		break;
		case '058':
		document.frm.bank2.value="GTBANK PLC";
		break;
		case '030':
		document.frm.bank2.value="HERITAGE BANK";
		break;
		case '082':
		document.frm.bank2.value="KEYSTONE BANK PLC";
		break;
		case '311':
		document.frm.bank2.value="PARKWAY";
		break;
		case '305':
		document.frm.bank2.value="PAYCOM";
		break;
		case '076':
		document.frm.bank2.value="POLARIS BANK PLC";
		break;
		case '221':
		document.frm.bank2.value="STANBIC IBTC BANK PLC";
		break;
		case '304':
		document.frm.bank2.value="STANBIC MOBILE";
		break;
		case '068':
		document.frm.bank2.value="STANDARD CHARTERED BANK NIGERIA LIMITED";
		break;
		case '232':
		document.frm.bank2.value="STERLING BANK PLC";
		break;
		case '032':
		document.frm.bank2.value="UNION BANK OF NIGERIA PLC";
		break;
		case '033':
		document.frm.bank2.value="UNITED BANK FOR AFRICA PLC";
		break;
		case '215':
		document.frm.bank2.value="UNITY BANK PLC";
		break;
		case '035':
		document.frm.bank2.value="WEMA BANK PLC";
		break;
		case '057':
		document.frm.bank2.value="ZENITH BANK PLC";
		break;
		case '322':
		document.frm.bank2.value="ZENITH MOBILE";
		break;
		case '559':
		document.frm.bank2.value="CORONATION MERCHANT BANK";
		break;
		case '101':
		document.frm.bank2.value="PROVIDUS BANK";
		break;
		case '526':
		document.frm.bank2.value="PARRALEX BANK";
		break;
		case '301':
		document.frm.bank2.value="JAIZ BANK";
		break;
		case '999129':
		document.frm.bank2.value="KUDA BANK";
		break;
		default:
		document.frm.bank2.value="select bank";

	}
}
</script>

