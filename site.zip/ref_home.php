
<div class="ref_div">


	<div class="ref_text">
		<h2 data-aos="zoom-in" data-aos-duration="2000">AFFILIATE PROGRAM</h2>

		<span data-aos="zoom-in" data-aos-duration="2000">Earn money by recommending our website to other people. 
Get a commission of  10% on each  first investment of the person who will register directly from your referral link. The affiliate program has 1 level of commission. Meaning you can only earn from your direct referrals.
Try to promote our website and share your referral link wherever you can. There are many ways and places to promote. E.g. You can make some testimonial video and publish it, advertise at forums, social media networks etc. Earned funds are immediately available for withdrawal at $100 minimum. </span>
	</div>

	<div class="ref_ik">
		<img src="pix/referral.png" class="ref_im" data-aos="zoom-in" data-aos-duration="2000"><br>
<a href="#u/o/?/page=register" class="index"><button type="button" class="reg_but2" data-aos="zoom-in" data-aos-duration="2000"><i class="fa fa-user-plus" id="urzj"> </i> Sign Up </button></a>

	</div>
</div>