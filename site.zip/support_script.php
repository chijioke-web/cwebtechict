<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$field_data=array('id int(100) not null auto_increment primary key',
	'sender varchar(100)not null',
'phone varchar(100)not null',
'email varchar(100)not null',
'sender_id varchar(100)not null',
'message text not null',
'datex varchar(100)',
'any varchar(100)not null'
);
$tb='msg_tb';
$crt=$obj->create_table($tb,$field_data);



$fields=array(
'sender',
'phone',
'email',
'sender_id',
'message',
'datex',
'any'

);
$name=$_SESSION['name'];
$phone=$_SESSION['phone'];
$email=$_SESSION['email'];
$id=$_SESSION['id'];
$msg=clean($_POST['msg']);
$date=date("d-m-Y");
$any='';

$values=array(
$name,
$phone,
$email,
$id,
$msg,
$date,
$any
);

$reg=$obj->send_txt($tb,$fields,$values);

?>