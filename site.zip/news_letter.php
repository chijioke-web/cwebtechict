<div class="letter">
<div class="letter2" data-aos="zoom-in" data-aos-duration="2000">
	<center><h2 style="color:white;"data-aos="zoom-in" data-aos-duration="2000">SUBSCRIBE TO OUR NEWS LETTER</h2></center>
<div class="lform" style="text-align:center;" data-aos="zoom-in" data-aos-duration="2000">

	<form id="newsletter"><i class="fa fa-envelope" id="fap"></i>
<input type="email" name="email" class="txt" placeholder="Your email" autocomplete="off" required></div><div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" data-aos="zoom-in" data-aos-duration="2000">Subscribe</button></div>

	</form>

</div></div>