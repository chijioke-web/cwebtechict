

<div class="navmem_container">

	<ul>
		<li class="kom" style="background: white;"><a href="?"><img src="pix/logo.png" width="200" height="100"></a><i class="fa fa-times-circle" id="urzhn"></i></li>
		<li><a href="?"><i class="fa fa-home" id="urm"></i> Registered Users <font color="yellow" size="2"><sup><?php $obj->registere_users('member_tb');?></sup></font></a></li>
		<li><a href="#" id="fund_user_ad"  class="index"><i class="fa fa-dollar" id="urm"></i> Confirm Pending Deposit <font color="yellow" size="2"><sup><?php $obj->funding_users('funding_tb','any','pending');?></sup></font></a></li>
		<li><a href="#"  id="pay_user_ad"  class="index"> <i class="fa fa-upload" id="urm"></i> Pay withdrawals <font color="yellow" size="2"><sup><?php $obj->funding_users('withdraw_tb','status','pending');?></sup></font></a></li>

		<li><a href="#" id="pay_user_bonus_ad"  class="index"> <i class="fa fa-upload" id="urm"></i> Pay Bonus <font color="yellow" size="2"><sup><?php $obj->funding_users('withdraw_bonus_tb','status','pending');?></sup></font></a></li>
		
		<li><a href="#u/o/?/page=change_password_ad"  class="index"><i class="fa fa-lock" id="urm"></i> Change Password</a></li>
		<li><a href="#u/o/?/page=announcement"  class="index"><i class="fa fa-bell" id="urm"></i> Make Announcement</a></li>
		<li><a href="#" id="view_msgx"  class="index"><i class="fa fa-eye" id="urm"></i> View Messages <font color="yellow" size="2"><sup><?php $obj->funding_users('msg_tb','any','');?></sup></font></a></li>
		
		<li><a href="#" id="trading_history_ad"  class="index"> <i class="fa fa-history" id="urm"></i> Investment History <font color="yellow" size="2"><sup><?php $obj->registere_users('trading_tb');?></sup></font></a></li>
		<?php 
		/*<li><a href="#" id="mining_history_ad"  class="index"> <i class="fa fa-history" id="urm"></i> Mining History <font color="yellow" size="2"><sup><?php $obj->registere_users('mining_tb');?></sup></font></a></li> 
		*/ ?>
		<li><a href="#" id="deposit_history_ad"  class="index"> <i class="fa fa-history" id="urm"></i> Deposit History <font color="yellow" size="2"><sup><?php $obj->registere_users('funding_tb');?></sup></font></a></li>
		<li><a href="#" id="widthdraw_history_ad"  class="index"> <i class="fa fa-history" id="urm"></i> Withdrawal History <font color="yellow" size="2"><sup><?php $obj->registere_users('withdraw_tb');?></sup></font></a></li>
		<li><a href="#" id="bonus_history_ad"  class="index"> <i class="fa fa-history" id="urm"></i> Bonus Withdrawal History <font color="yellow" size="2"><sup><?php $obj->registere_users('withdraw_bonus_tb');?></sup></font></a></li>

		<li><a href="#" id="logout_ad"><i class="fa fa-power-off" id="urm" style="color:red"></i> Logout</a></li>


	</ul></div>