

       
$(document).ready(function(){
//send message by users
$("#contact_forma").submit(function(e){
e.preventDefault();

  $.ajax({
          url: "msg_public_script.php",
      type: "POST",
      data:  new FormData(this),
      contentType: false,
          cache: false,
      processData:false,

         beforeSend: function() 
        {
       $(".reg_but2").html("Sending...<img src='pix/loading51.gif' width='20'/>").css({"opacity":"0.4","cursor":"not-allowed"});
    $(".reg_but2").attr("disabled",true);
    $(".loader").fadeIn(10);
        },
      success: function(data)
        {
            if(data==1){
             $(".msg").fadeIn(2000);
      $(".msg").html('Message sent successfully ...<img src="pix/loading51.gif" width="20"/>').css("background-color","rgba(0,0,0,0.7)");
      $(".loader").hide(10);

             $(".txt").val('');
              $(".txtz").val('');
              setTimeout(function(){$(".msg").fadeOut(2000)},3000);
              $(".reg_but2").html('Send Message').css({"opacity":"1","cursor":"pointer"});
            }
            else{ 
              
          $(".msg").fadeIn(2000);
          $(".msg").css("background-color","red");
      $(".msg").html(data);
  $(".reg_but2").html('Send Message').css({"opacity":"1","cursor":"pointer"});
  $(".loader").hide(10);
  $(".reg_but2").attr("disabled",false);
  setTimeout(function(){$(".msg").fadeOut(2000)},3000);
}
        }
           
     });
  });
//last
});


