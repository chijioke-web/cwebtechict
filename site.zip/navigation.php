<nav>
	<ul>
		<li class="kom" style="background: white;"><a href="?"><img src="pix/logo.png" width="200" height="100"></a><i class="fa fa-times-circle" id="urzhn"></i></li>
		<li><a href="?"><i class="fa fa-home" id="ur"></i> Home</a></li>
		<li><a href="#u/o/?/page=about" class="index"> <i class="fa fa-user" id="ur"></i> About Us</a></li>
		<li><a href="#u/o/?/page=contact" class="index"><i class="fa fa-envelope" id="ur"></i> Contact Us</a></li>
		<li><a href="#u/o/?/page=steps" class="index"><i class="fa fa-wrench" id="ur"></i> How it works</a></li>
		<li><a href="#u/o/?/page=plans" class="index"><i class="fa fa-gear" id="ur"></i> Plans</a></li>
		<li><a href="#u/o/?/page=faq" class="index"><i class="fa fa-question-circle" id="ur"></i> FAQ</a></li>
		<li><a href="#u/o/?/page=register" class="index"><i class="fa fa-user-plus" id="urz"> Sign Up </i></a></li>
		<li id="login_navigation"><a href="#u/o/?/page=login" class="index"><i class="fa fa-sign-in" id="urz"> Login </i></a></li>
	</ul>
</nav>