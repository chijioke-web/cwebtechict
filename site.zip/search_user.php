<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';
$ref='email';
$search= clean($_GET['phone']);
 $obj->view_member_search('member_tb','name','phone','email','ref_email','wallet','ref_wallet','datex','id',$search);
?>