<?php
require 'main_class.php';
$obj=new WEB_CONTROL();


 $obj->total_reg('member_tb',1000);


?>