<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';
$td='trading_tb';
$id='id';
$idd=$_SESSION['id'];
$amount=clean($_POST['profit']);
$wallet='wallet';
$idx='id';
$idxc=clean($_POST['id']);
$ocr='acrud_profit';
$obj->transfer_to_wallet($tb,$td,$id,$idd,$amount,$wallet,$idx,$idxc,$ocr);

?>