<script type="text/javascript" src="js/java2.js"></script>


<br><br><br>
<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Transfer Fund</h3>
		<form id="transfer_form" method="post">
		


<div class="lform" style="text-align:center;" >

	<i class="fa fa-dollar" id="fap" aria-hidden="true"></i>
<input type="number" name="amt" class="txt" placeholder="Enter amount" autocomplete="off" required min="10" max="300000000000000000000"></div>

<div class="lform" style="text-align:center;" >

	<i class="fa fa-envelope" id="fap" aria-hidden="true"></i>
<input type="email" name="email" class="txt" placeholder="Enter Receivers's Email" autocomplete="off" required></div>







<div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" id="reg_button" > <i class="fa fa-sign-in" id="uroo"> </i> Transfer Fund</button><br> <br><br></div>

	<div  class="load_chat" style="width:100%"></div>

</div>
</form>

	</div>



</div>
