<div class="msgl"></div>

<div class="copy">

	Copyright © <?php echo date("Y");?>, <span style="color:#990033">Squixfund</span>. All Right Reserved<br><br>

</div>