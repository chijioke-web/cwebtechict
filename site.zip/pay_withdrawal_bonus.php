
<script type="text/javascript" src="js/java2.js"></script>

<br>
<div class="contact">

		
<button type="button" class="back" onclick="history.back()"><-Back</button>

	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Pay Referral Bonus</h3>
		


<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';

$tb='withdraw_bonus_tb';
$id='id';
$amount='amount';
$status='status';
$date='datex';
$accno='coin';
$accna='wallet';
$bank='network';
$active='pending';
$name='name';

$log=$obj->pay_user_bonus($tb,$name,$amount,$id,$status,$active,$date,$accno,$accna,$bank);

    


?><br> <br><br></div>

	

</div>


	</div>



</div>

