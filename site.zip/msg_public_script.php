<?php
require 'main_class.php';
$obj=new WEB_CONTROL();
$conn=$obj->connect();
require 'clean.php';
$tb='member_tb';

$email=clean($_POST['email']);
$msg=clean($_POST['msg']);
$na=clean($_POST['name']);
$phone=clean($_POST['phone']);
$city=clean($_POST['city']);
$log=$obj->send_email_public($na,$msg,$phone,$city,$email);

?>