<script type="text/javascript" src="js/java2.js"></script>


<br><br><br>
<div class="contact">

		

<button type="button" class="back" onclick="history.back()"><-Back</button>
	<div class="form_con_reg">
		<h3 align="center" style="font-family: microsoft new tai lue"> Change Password</h3>
		<form id="pass_change_form_ad" method="post">
		




<div class="lform" style="text-align:center;" >

	<i class="fa fa-lock" id="fap" aria-hidden="true"></i>
<input type="password" name="password" class="txt" placeholder="Enter new password" autocomplete="off" required id="txt"></div>
<div class="showp">
<input type="checkbox" class="ckbox"><span id="ckbox">Show Password</span>
</div>




<div style="text-align:center"><div class="loader"><img src="pix/loading51.gif" class="load_in"></div><div class="msg"></div><button type="submit" class="reg_but2" id="reg_button" >  Change </button><br> <br><br></div>

	

</div>
</form>

	</div>



</div>
