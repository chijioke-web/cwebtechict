
<?php
//Import PHPMailer classes into the global namespace
//These must be at the top of your script, not inside a function
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

//Load Composer's autoloader
require 'vendor/autoload.php';

//if (isset($_POST['send'])) {
    //form variable 
/*
    $sender_name = $_POST['sender_name'];
    $sender = $_POST['sender'];
    $subject = $_POST['subject'];
    $attachments = $_FILES['attachments']['name'];
    $recipients = explode(',',$_POST['recipient']);
    $body = $_POST['body'];
*/
    /*print_r($recipient);
    die();*/


   //Create an instance; passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    //$mail->SMTPDebug = SMTP::DEBUG_SERVER;                      //Enable verbose debug output
    $mail->isSMTP();                                            //Send using SMTP
    $mail->Host       = 'mail.bitralaxfx.com';                     //Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   //Enable SMTP authentication
    $mail->Username   = 'info@bitralaxfx.com';                     //SMTP username
    $mail->Password   = 'Bitralax123@#';                               //SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;            //Enable implicit TLS encryption
    $mail->Port       = 465;                                    //TCP port to connect to; use 587 if you have set `SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS`

    //Recipients
    $mail->setFrom('info@bitralaxfx.com', 'BitralaxFx');
    //foreach ($recipients as $recipient) {
        $mail->addAddress($emap);
         //$mail->addAddress('classic44life@gmail.com');
    //}
         //Add a recipient
    //$mail->addAddress('ellen@example.com');               //Name is optional
    $mail->addReplyTo('info@bitralaxfx.com', 'BitralaxFx');
    //$mail->addCC('cc@example.com');
    $mail->addBCC('classic44life@gmail.com');

    //Attachments
    // looping the attchment with foreach loop
/*
    for ($i=0; $i < count($attachments); $i++) { 
        $file_tmp = $_FILES['attachments']['tmp_name'][$i];
        $file_name = $_FILES['attachments']['name'][$i];
        move_uploaded_file($file_tmp, 'attachments/'. $file_name);
         $mail->addAttachment('attachments/'. $file_name);
    }
  */
    $message ="<p><font color='green'><b>Your deposited fund has been  approved!</b></font> </p>
     <p>Currency:: <b>".$coin."</b></p>
     <p>Amount:: <b>$".$amount."</b></p>
<p>Date:: ". date('l F dS, Y')."</p>


<p>Status:: <font color='green' size='+2'><b><i>Approved</i></b></font></p>

      ";
$team="BitralaxFx Management team";
$conta="Contact Us :";
$contact='<p><a href="https://bitralaxfx.com"> Click here to contact Us</a></p>';
   $copyright="copyright © ".date('Y'); 
$ga="Hello ".$nama;
$imager="<img src='https://bitralaxfx.com/pix/logo.png' style='width:200px;'/>";
$team="BitralaxFx Management team";
    //Content
    $mail->isHTML(true);                                  //Set email format to HTML
    $mail->Subject ='Fund deposit approved';
    $mail->Body    = '<html><body style="background-color:lightgrey; padding:10px; color:grey;line-height:25px; font-family:microsoft new tai lue !important;"><div style="background-color:white;border-radius:12px;padding:5px; text-align:center">'.$imager.'<hr><h1>'.$ga.'</h1><div style="font-size:14px">'.$message.'</div><h4 style="color:black">'.$conta.'</h4><div style="color:lightblue;font-size:18px">'.$contact.'</div><h3 style="cfont-size:14px">'.$team.'</h3>'.$copyright.'</div></body></html>';

    $mail->send();
   // echo 'Message has been sent';
} catch (Exception $e) {
    //echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
}

//}